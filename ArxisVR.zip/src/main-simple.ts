/**
 * ArxisVR - Fast Start Mode (Optimized)
 * - Lazy loading: componentes carregados sob demanda
 * - Renderização otimizada com fog
 * - Sistemas pesados removidos do boot
 * - UI Runtime integrado com AppController/ToolManager/CommandHistory
 */
import * as THREE from 'three';
import { ComponentsRegistry, componentManager, isTypingInUI, hasOpenUI } from './components-registry';
import { IFCLoader } from './loaders/IFCLoader';
import { LODSystem } from './systems/LODSystem';
import { EntityManager } from './engine/ecs';
import { eventBus } from './core';
import { AppController } from './app/AppController';
import { initializeUI } from './ui/UI';
import { fileService } from './systems/file';
import { ModelSession } from './systems/model/ModelSession';

// Performance tracking
performance.mark('app-start');

console.log('🚀 ArxisVR - Fast Start Mode');
console.log(`📦 ${Object.keys(ComponentsRegistry).length} componentes disponíveis (lazy load)`);

// Hide loading IMMEDIATELY (no timeout)
const loading = document.getElementById('loading');
if (loading) {
  loading.classList.add('hidden');
  setTimeout(() => loading.remove(), 300);
}

// Create scene
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0a0a0f);
scene.fog = new THREE.Fog(0x0a0a0f, 50, 200); // Fog para melhor performance

// Create camera
const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);
camera.position.set(5, 1.7, 5);

performance.mark('scene-ready');
performance.measure('init-time', 'app-start', 'scene-ready');
const initTime = performance.getEntriesByName('init-time')[0].duration;
console.log(`✅ Scene + Camera prontos em ${initTime.toFixed(0)}ms`);

// Camera rotation (Euler angles)
const euler = new THREE.Euler(0, 0, 0, 'YXZ');
const PI_2 = Math.PI / 2;

// Movement state
const movement = {
  forward: false,
  backward: false,
  left: false,
  right: false,
  up: false,
  down: false,
  speed: 0.1
};

// Spatial mode (fly mode)
let spatialMode = false;

// Rotation state (Arrow keys)
const rotation = {
  up: false,
  down: false,
  left: false,
  right: false,
  speed: 0.03
};

// Mouse look
let isPointerLocked = false;

// Keyboard controls (com InputGate para não conflitar com UI)
window.addEventListener('keydown', (e) => {
  // Bloqueia movimento se usuário estiver digitando em input/modal
  if (isTypingInUI(e)) return;
  
  const key = e.key.toLowerCase();
  
  // Movimento WASD (funciona sempre, pointer lock ou não)
  switch(key) {
    case 'w': 
      movement.forward = true;
      console.log('W pressed - forward:', movement.forward);
      break;
    case 's': movement.backward = true; break;
    case 'a': movement.left = true; break;
    case 'd': movement.right = true; break;
    case ' ': 
      movement.up = true; 
      e.preventDefault(); 
      break;
    case 'shift': 
      movement.down = true; 
      e.preventDefault(); 
      break;
    case 'arrowup': rotation.up = true; e.preventDefault(); break;
    case 'arrowdown': rotation.down = true; e.preventDefault(); break;
    case 'arrowleft': rotation.left = true; e.preventDefault(); break;
    case 'arrowright': rotation.right = true; e.preventDefault(); break;
  }
});

window.addEventListener('keyup', (e) => {
  // InputGate: não reseta movimento se estava digitando
  if (isTypingInUI(e)) return;
  
  const key = e.key.toLowerCase();
  
  switch(key) {
    case 'w': 
      movement.forward = false;
      console.log('W released - forward:', movement.forward);
      break;
    case 's': movement.backward = false; break;
    case 'a': movement.left = false; break;
    case 'd': movement.right = false; break;
    case ' ': movement.up = false; break;
    case 'shift': movement.down = false; break;
    case 'arrowup': rotation.up = false; break;
    case 'arrowdown': rotation.down = false; break;
    case 'arrowleft': rotation.left = false; break;
    case 'arrowright': rotation.right = false; break;
  }
});

console.log('✅ WASD + Arrow keys + Space/Shift controls added');

// Get canvas container
const container = document.getElementById('canvas-container');
if (!container) {
  console.error('❌ Canvas container not found!');
  throw new Error('Canvas container not found');
}

// Create renderer (performance-optimized)
const renderer = new THREE.WebGLRenderer({ 
  antialias: false, // Desabilitar AA para melhor performance
  powerPreference: 'high-performance',
  stencil: false,
  depth: true
});
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2)); // Limitar a 2x para performance
renderer.shadowMap.enabled = false; // Desabilitar sombras por padrão
container.appendChild(renderer.domElement);
console.log('✅ Renderer otimizado criado');

// Pointer Lock (Mouse look - FPS style) - Only when double-clicking canvas
renderer.domElement.addEventListener('dblclick', () => {
  // Não trava mouse se qualquer UI estiver aberta
  if (!hasOpenUI()) {
    renderer.domElement.requestPointerLock();
  }
});

// Exit pointer lock with ESC (com InputGate)
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    // Se tem UI aberta, fecha a UI (prioridade)
    if (hasOpenUI()) {
      // UI Runtime/ComponentManager já gerencia o ESC
      return;
    }
    // Se não tem UI mas pointer lock ativo, sai do pointer lock
    if (isPointerLocked) {
      document.exitPointerLock();
    }
  }
});

document.addEventListener('pointerlockchange', () => {
  isPointerLocked = document.pointerLockElement === renderer.domElement;
  console.log(isPointerLocked ? '🖱️ Mouse locked (ESC to exit)' : '🖱️ Mouse unlocked');
});

document.addEventListener('mousemove', (e) => {
  if (!isPointerLocked) return;
  
  const movementX = e.movementX || 0;
  const movementY = e.movementY || 0;
  
  euler.setFromQuaternion(camera.quaternion);
  euler.y -= movementX * 0.002;
  euler.x -= movementY * 0.002;
  euler.x = Math.max(-PI_2, Math.min(PI_2, euler.x));
  camera.quaternion.setFromEuler(euler);
});

console.log('✅ Mouse look controls added (double-click to lock, ESC to exit)');

// Add lights
const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
directionalLight.position.set(10, 10, 10);
scene.add(directionalLight);
console.log('✅ Lights added');

// Add grid (reduced for performance)
const gridHelper = new THREE.GridHelper(20, 10, 0x00d4ff, 0x222222); // Menos linhas
scene.add(gridHelper);

// Add axes
const axesHelper = new THREE.AxesHelper(5);
scene.add(axesHelper);

console.log('✅ Scene setup completo');

// Lazy initialization - só cria quando necessário
let entityManager: EntityManager | null = null;
let lodSystem: LODSystem | null = null;
let ifcLoader: IFCLoader | null = null;
let modelSession: ModelSession | null = null;

function initializeModelSession() {
  if (!modelSession) {
    console.log('⏳ Inicializando ModelSession...');
    modelSession = ModelSession.getInstance(scene, camera);
    fileService.setModelSession(modelSession);
    console.log('✅ ModelSession inicializada');
  }
  return modelSession;
}

function initializeIFCLoader() {
  if (!ifcLoader) {
    console.log('⏳ Inicializando IFC Loader...');
    entityManager = new EntityManager();
    lodSystem = new LODSystem(camera);
    ifcLoader = new IFCLoader(scene, lodSystem, entityManager);
    
    // Inicializa ModelSession se ainda não foi
    initializeModelSession();
    
    console.log('✅ IFC Loader inicializado');
  }
  return ifcLoader;
}

// Global function to load IFC files (lazy init)
(window as any).loadIFCFile = async (file: File) => {
  try {
    console.log(`📦 Loading IFC: ${file.name}`);
    const loader = initializeIFCLoader();
    await loader.loadIFC(file);
    console.log(`✅ IFC loaded successfully: ${file.name}`);
  } catch (error) {
    console.error('❌ Error loading IFC:', error);
    alert(`Erro ao carregar IFC: ${error}`);
  }
};

// Add a simple test cube
const geometry = new THREE.BoxGeometry(1, 1, 1);
const material = new THREE.MeshBasicMaterial({ color: 0x00d4ff }); // BasicMaterial é mais leve
const cube = new THREE.Mesh(geometry, material);
cube.position.y = 0.5;
scene.add(cube);

// Handle resize
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// Animation loop
function animate() {
  requestAnimationFrame(animate);
  
  // Apply rotation (Arrow keys)
  euler.setFromQuaternion(camera.quaternion);
  
  if (rotation.up) {
    euler.x += rotation.speed;
  }
  if (rotation.down) {
    euler.x -= rotation.speed;
  }
  if (rotation.left) {
    euler.y += rotation.speed;
  }
  if (rotation.right) {
    euler.y -= rotation.speed;
  }
  
  // Clamp vertical rotation
  euler.x = Math.max(-PI_2, Math.min(PI_2, euler.x));
  camera.quaternion.setFromEuler(euler);
  
  // Calculate movement direction based on camera rotation
  const direction = new THREE.Vector3();
  
  if (movement.forward) {
    direction.z -= movement.speed;
  }
  if (movement.backward) {
    direction.z += movement.speed;
  }
  if (movement.left) {
    direction.x -= movement.speed;
  }
  if (movement.right) {
    direction.x += movement.speed;
  }
  
  // Vertical movement (only in spatial mode)
  if (spatialMode) {
    if (movement.up) {
      direction.y += movement.speed;
    }
    if (movement.down) {
      direction.y -= movement.speed;
    }
  }
  
  // Apply movement relative to camera direction
  if (direction.length() > 0) {
    if (spatialMode) {
      // Full 3D movement in spatial mode
      direction.applyQuaternion(camera.quaternion);
      camera.position.add(direction);
    } else {
      // Horizontal movement only in normal mode
      const yRotation = new THREE.Euler(0, euler.y, 0, 'YXZ');
      const quaternion = new THREE.Quaternion().setFromEuler(yRotation);
      const horizontalDir = new THREE.Vector3(direction.x, 0, direction.z);
      horizontalDir.applyQuaternion(quaternion);
      camera.position.add(horizontalDir);
    }
  }
  
  // Rotate cube
  cube.rotation.x += 0.01;
  cube.rotation.y += 0.01;
  
  // Update ModelSession (LOD, frustum culling, adaptive quality)
  if (modelSession) {
    modelSession.update(0.016); // ~60fps
  }
  
  renderer.render(scene, camera);
}

animate();

// Final performance report
performance.mark('app-ready');
performance.measure('total-load', 'app-start', 'app-ready');
const totalTime = performance.getEntriesByName('total-load')[0].duration;
console.log('✅ Animation loop started');
console.log(`🎉 ArxisVR carregado em ${totalTime.toFixed(0)}ms`);
console.log('💡 Dica: Use duplo-clique para controle FPS, ESC para sair');
console.log('💡 Ctrl+O para abrir arquivos IFC');

// Multiplayer button
const mpButton = document.querySelector('.connect-multiplayer-btn') as HTMLButtonElement;
if (mpButton) {
  mpButton.addEventListener('click', () => {
    alert('Multiplayer feature coming soon!');
  });
}

// Spatial mode button
const spatialButton = document.querySelector('.spatial-mode-btn') as HTMLButtonElement;
if (spatialButton) {
  spatialButton.addEventListener('click', () => {
    spatialMode = !spatialMode;
    
    if (spatialMode) {
      spatialButton.classList.add('active');
      spatialButton.innerHTML = '🚀 Modo Espacial (ON)';
      console.log('🚀 Spatial mode enabled - Use Space/Shift to fly up/down');
    } else {
      spatialButton.classList.remove('active');
      spatialButton.innerHTML = '🚀 Modo Espacial';
      console.log('🚶 Normal mode - Walking on ground');
    }
  });
  console.log('✅ Spatial mode button ready');
}

// Toolbar buttons
const toolbarButtons = document.querySelectorAll('.toolbar-btn');
console.log(`🔍 Found ${toolbarButtons.length} toolbar buttons`);

// Mapeamento tool -> componentName
const toolComponentMap: Record<string, string> = {
  'measure': 'MeasurementPanel',
  'section': 'SectionBoxTool',
  'layers': 'LayersPanel',
  'transparency': 'TransparencyControl',
  'explode': 'ExplodeViewPanel',
  'camera': 'CameraPresetsPanel',
  'annotate': 'AnnotationsPanel',
  'comments': 'ChatPanel',
  'settings': 'SettingsPanel'
};

toolbarButtons.forEach((button, index) => {
  console.log(`  Button ${index}: ${button.getAttribute('data-tool')}`);
  button.addEventListener('click', async () => {
    const tool = button.getAttribute('data-tool');
    if (!tool) return;
    
    console.log(`🖱️ CLICK on button: ${tool}`);
    
    // Update active state
    toolbarButtons.forEach(btn => btn.classList.remove('active'));
    button.classList.add('active');
    
    // Handle special tools
    switch(tool) {
      case 'select':
        console.log('👆 Ferramenta: Selecionar');
        // Close all panels on select
        componentManager.closeAll();
        break;
      
      case 'vr':
        console.log('🥽 Ferramenta: Modo VR');
        alert('VR: Entrar em modo VR/AR (requer headset WebXR)');
        break;
      
      case 'menu':
        console.log('☰ Abrindo menu de componentes');
        const menu = document.getElementById('components-menu');
        if (menu) {
          menu.style.display = 'flex';
        }
        break;
      
      default:
        // Handle panel-based tools via componentManager
        const componentName = toolComponentMap[tool];
        if (componentName) {
          console.log(`🔧 Tool: ${tool} → Component: ${componentName}`);
          await componentManager.toggle(`tool:${tool}`, componentName);
        }
        break;
    }
  });
});

// Keyboard shortcuts for tools (com InputGate + ComponentManager)
window.addEventListener('keydown', async (e) => {
  // InputGate: não dispara hotkeys se usuário está digitando
  if (isTypingInUI(e)) return;
  if (isPointerLocked) return; // Não dispara quando mouse travado
  
  // Ctrl+O to open file
  if (e.ctrlKey && e.key.toLowerCase() === 'o') {
    e.preventDefault();
    console.log('📁 Ctrl+O: Opening LoadFileModal');
    await componentManager.open('modal:load-file', 'LoadFileModal');
    return;
  }
  
  // Hotkeys de ferramentas (Q/M/C/L/T/E/V/A/K/,)
  let toolKey: string | null = null;
  let componentName: string | null = null;
  
  switch(e.key.toLowerCase()) {
    case 'q': toolKey = 'tool:select'; break; // Select (não abre painel)
    case 'm': toolKey = 'tool:measure'; componentName = 'MeasurementPanel'; break;
    case 'c': toolKey = 'tool:section'; componentName = 'SectionBoxTool'; break;
    case 'l': toolKey = 'tool:layers'; componentName = 'LayersPanel'; break;
    case 't': toolKey = 'tool:transparency'; componentName = 'TransparencyControl'; break;
    case 'e': toolKey = 'tool:explode'; componentName = 'ExplodeViewPanel'; break;
    case 'v': toolKey = 'tool:camera'; componentName = 'CameraPresetsPanel'; break;
    case 'a': toolKey = 'tool:annotate'; componentName = 'AnnotationsPanel'; break;
    case 'k': toolKey = 'tool:comments'; componentName = 'ChatPanel'; break;
    case ',': toolKey = 'tool:settings'; componentName = 'SettingsPanel'; break;
  }
  
  if (toolKey && componentName) {
    await componentManager.toggle(toolKey, componentName);
  } else if (e.key.toLowerCase() === 'q') {
    // Select tool (apenas simula click no botão)
    const selectBtn = document.querySelector('[data-tool="select"]');
    if (selectBtn) (selectBtn as HTMLElement).click();
  }
});

console.log('✅ Toolbar initialized with 11 tools + Ctrl+O shortcut');

// Components Menu Management
const componentsMenu = document.getElementById('components-menu');
const closeMenuBtn = document.querySelector('.close-menu');
const componentButtons = document.querySelectorAll('[data-component]');

// Close menu button
if (closeMenuBtn) {
  closeMenuBtn.addEventListener('click', () => {
    if (componentsMenu) {
      componentsMenu.style.display = 'none';
    }
  });
}

// Component buttons in menu
console.log(`🔍 Found ${componentButtons.length} component buttons in menu`);
componentButtons.forEach((button) => {
  button.addEventListener('click', async () => {
    const componentName = button.getAttribute('data-component');
    if (!componentName) return;
    
    console.log(`🖱️ Creating component: ${componentName}`);
    
    // Close menu
    if (componentsMenu) {
      componentsMenu.style.display = 'none';
    }
    
    // Usa componentManager para abrir/toggle
    await componentManager.open(`menu:${componentName}`, componentName);
  });
});

// Menu bar buttons (same logic as component buttons)
const menuBarButtons = document.querySelectorAll('.menu-bar-dropdown button[data-component]');
console.log(`🔍 Found ${menuBarButtons.length} menu bar buttons`);
menuBarButtons.forEach((button) => {
  button.addEventListener('click', async () => {
    const componentName = button.getAttribute('data-component');
    if (!componentName) return;
    
    console.log(`🖱️ Creating component from menu bar: ${componentName}`);
    
    // Usa componentManager para abrir
    await componentManager.open(`menubar:${componentName}`, componentName);
  });
});

console.log('✅ Components menu initialized');
console.log('✅ Menu bar initialized');

// Export for debugging
if (typeof window !== 'undefined') {
  (window as any).scene = scene;
  (window as any).camera = camera;
  (window as any).renderer = renderer;
}

// =============================================================================
// UI RUNTIME - Conecta HTML aos sistemas reais
// =============================================================================

console.log('🎨 Inicializando UI Runtime...');

// Instancia AppController (gerenciador central da aplicação)
const appController = AppController.getInstance();

// Configura referências da engine no AppController
// Type cast: main-simple usa THREE.Scene diretamente (bootstrap mode)
appController.setEngineReferences(
  scene as any, // TODO: Usar ThreeSceneAdapter para type safety
  camera as any,
  renderer as any
);

// Register basic tools in ToolManager (prevents "not registered" errors)
const toolManager = appController.toolManager;
if (toolManager) {
  const basicTools = [
    { id: 'navigation', name: 'Navigation' },
    { id: 'select', name: 'Selection' },
    { id: 'measurement', name: 'Measurement' },
    { id: 'section', name: 'Section' },
    { id: 'layer', name: 'Layer' }
  ];
  
  basicTools.forEach(tool => {
    toolManager.registerTool(tool.id as any, {
      id: tool.id,
      name: tool.name,
      activate: () => console.log(`🔧 ${tool.name} tool activated`),
      deactivate: () => console.log(`🔧 ${tool.name} tool deactivated`)
    });
  });
  
  console.log(`✅ ${basicTools.length} basic tools registered`);
}

// Inicializa UIRuntime com dependências reais
const uiRuntime = initializeUI(
  eventBus,                        // EventBus real (src/core/EventBus.ts)
  appController,                    // AppController (src/app/AppController.ts)
  appController.toolManager,        // ToolManager (src/app/ToolManager.ts)
  (window as any).commandHistory || { undo: () => {}, redo: () => {} }, // CommandHistory
  undefined                         // NetworkManager (opcional)
);

console.log('✅ UI Runtime conectado aos sistemas');

// Exporta para debug
if (typeof window !== 'undefined') {
  (window as any).appController = appController;
  (window as any).uiRuntime = uiRuntime;
  console.log('   - window.appController');
  console.log('   - window.uiRuntime');
  console.log('   - window.loadIFCFile(file) [já definido acima]');
}

