export { VRInputManager } from './VRInputManager';
export { GestureRecognizer } from './GestureRecognizer';
export type { GestureType, GestureData } from './GestureRecognizer';
export { HapticFeedback } from './HapticFeedback';
