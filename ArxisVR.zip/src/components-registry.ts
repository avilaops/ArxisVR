/**
 * Registry de TODOS os 46+ componentes do ArxisVR
 */

// BIM 4D/5D/6D
import { TimelinePanel } from './ui/panels-v2/TimelinePanel';
import { SchedulePanel } from './ui/panels-v2/SchedulePanel';
import { CostDashboard } from './ui/panels-v2/CostDashboard';
import { QuantitiesPanel } from './ui/panels-v2/QuantitiesPanel';
import { FacilityPanel } from './ui/panels-v2/FacilityPanel';
import { MaintenancePanel } from './ui/panels-v2/MaintenancePanel';

// Visualização Avançada
import { MaterialEditor } from './ui/panels-v2/MaterialEditor';
import { LightingPanel } from './ui/panels-v2/LightingPanel';
import { ClippingPlanesEditor } from './ui/panels-v2/ClippingPlanesEditor';
import { SectionBoxTool } from './ui/panels-v2/SectionBoxTool';
import { ExplodeViewPanel } from './ui/panels-v2/ExplodeViewPanel';
import { TransparencyControl } from './ui/panels-v2/TransparencyControl';
import { CameraPresetsPanel } from './ui/panels-v2/CameraPresetsPanel';

// Colaboração
import { ChatPanel } from './ui/panels-v2/ChatPanel';
import { AnnotationsPanel } from './ui/panels-v2/AnnotationsPanel';
import { IssuesPanel } from './ui/panels-v2/IssuesPanel';
import { UserPresenceWidget } from './ui/panels-v2/UserPresenceWidget';
import { ActivityFeed } from './ui/panels-v2/ActivityFeed';

// Busca e Filtros
import { AdvancedSearchPanel } from './ui/panels-v2/AdvancedSearchPanel';
import { FilterBuilder } from './ui/panels-v2/FilterBuilder';
import { SavedFiltersPanel } from './ui/panels-v2/SavedFiltersPanel';
import { SelectionSetsPanel } from './ui/panels-v2/SelectionSetsPanel';

// Gerenciamento
import { FileBrowser } from './ui/panels-v2/FileBrowser';
import { RecentProjects } from './ui/panels-v2/RecentProjects';
import { CloudStoragePanel } from './ui/panels-v2/CloudStoragePanel';
import { VersionHistory } from './ui/panels-v2/VersionHistory';
import { ProjectExplorer } from './ui/panels-v2/ProjectExplorer';
import { IFCPropertyPanel } from './ui/panels-v2/IFCPropertyPanel';
import { LayersPanel } from './ui/panels-v2/LayersPanel';
import { MeasurementPanel } from './ui/panels-v2/MeasurementPanel';

// Analytics & Reports
import { DashboardWidget } from './ui/panels-v2/DashboardWidget';
import { ChartsPanel } from './ui/panels-v2/ChartsPanel';
import { ReportViewer } from './ui/panels-v2/ReportViewer';
import { ExportReportButton } from './ui/panels-v2/ExportReportButton';

// WebXR/VR/AR
import { VRControlsPanel } from './ui/panels-v2/VRControlsPanel';
import { VRTeleportUI } from './ui/panels-v2/VRTeleportUI';
import { VRMenuRadial } from './ui/panels-v2/VRMenuRadial';
import { ARMeasurementUI } from './ui/panels-v2/ARMeasurementUI';

// Interface & Ajuda
import { KeyboardShortcutsPanel } from './ui/panels-v2/KeyboardShortcutsPanel';
import { HelpPanel } from './ui/panels-v2/HelpPanel';
import { TutorialOverlay } from './ui/panels-v2/TutorialOverlay';
import { CommandPalette } from './ui/panels-v2/CommandPalette';
import { ThemePicker } from './ui/panels-v2/ThemePicker';
import { LanguageSelector } from './ui/panels-v2/LanguageSelector';
import { SettingsPanel } from './ui/panels-v2/SettingsPanel';

// Modais
import { LoadFileModal } from './ui/modals/LoadFileModal';
import { ExportModal } from './ui/modals/ExportModal';
import { ShareModal } from './ui/modals/ShareModal';
import { VersionCompareModal } from './ui/modals/VersionCompareModal';
import { ConflictDetectionModal } from './ui/modals/ConflictDetectionModal';
import { ReportGeneratorModal } from './ui/modals/ReportGeneratorModal';

// Registry de construtores
export const ComponentsRegistry: Record<string, any> = {
  // BIM 4D/5D/6D
  TimelinePanel,
  SchedulePanel,
  CostDashboard,
  QuantitiesPanel,
  FacilityPanel,
  MaintenancePanel,
  
  // Visualização
  MaterialEditor,
  LightingPanel,
  ClippingPlanesEditor,
  SectionBoxTool,
  ExplodeViewPanel,
  TransparencyControl,
  CameraPresetsPanel,
  
  // Colaboração
  ChatPanel,
  AnnotationsPanel,
  IssuesPanel,
  UserPresenceWidget,
  ActivityFeed,
  
  // Busca
  AdvancedSearchPanel,
  FilterBuilder,
  SavedFiltersPanel,
  SelectionSetsPanel,
  
  // Gerenciamento
  FileBrowser,
  RecentProjects,
  CloudStoragePanel,
  VersionHistory,
  ProjectExplorer,
  IFCPropertyPanel,
  LayersPanel,
  MeasurementPanel,
  
  // Analytics
  DashboardWidget,
  ChartsPanel,
  ReportViewer,
  ExportReportButton,
  
  // VR/AR
  VRControlsPanel,
  VRTeleportUI,
  VRMenuRadial,
  ARMeasurementUI,
  
  // Interface
  KeyboardShortcutsPanel,
  HelpPanel,
  TutorialOverlay,
  CommandPalette,
  ThemePicker,
  LanguageSelector,
  SettingsPanel,
  
  // Modais
  LoadFileModal,
  ExportModal,
  ShareModal,
  VersionCompareModal,
  ConflictDetectionModal,
  ReportGeneratorModal
};

export function createComponent(name: string): any {
  const ComponentClass = ComponentsRegistry[name];
  if (!ComponentClass) {
    console.error(`❌ Componente não encontrado: ${name}`);
    return null;
  }
  
  try {
    return new ComponentClass();
  } catch (error) {
    console.error(`❌ Erro ao criar componente ${name}:`, error);
    return null;
  }
}
