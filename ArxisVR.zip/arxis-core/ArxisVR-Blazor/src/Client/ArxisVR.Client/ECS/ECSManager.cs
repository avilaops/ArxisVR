using Microsoft.JSInterop;

namespace ArxisVR.Client.ECS;

/// <summary>
/// ECSManager - Gerenciador do Entity Component System
/// Performance crítica para milhares de elementos IFC
/// </summary>
public class ECSManager
{
    private readonly IJSRuntime _jsRuntime;
    private IJSObjectReference? _ecsModule;
    
    // Entity storage
    private readonly Dictionary<int, Entity> _entities = new();
    private int _nextEntityId = 1;
    
    // Component queries (cache para performance)
    private readonly Dictionary<Type, List<Entity>> _componentCache = new();
    
    // Events
    public event Action<Entity>? OnEntityCreated;
    public event Action<Entity>? OnEntityDestroyed;
    
    public ECSManager(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }
    
    /// <summary>
    /// Inicializa ECS
    /// </summary>
    public async Task InitializeAsync()
    {
        _ecsModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/ecs.js");
            
        await _ecsModule.InvokeVoidAsync("initializeECS");
        Console.WriteLine("✅ ECS Manager initialized");
    }
    
    /// <summary>
    /// Cria nova entity
    /// </summary>
    public Entity CreateEntity(string name = "Entity")
    {
        var id = _nextEntityId++;
        var entity = new Entity(id, name);
        _entities[id] = entity;
        
        OnEntityCreated?.Invoke(entity);
        
        Console.WriteLine($"🆕 Entity created: {entity}");
        return entity;
    }
    
    /// <summary>
    /// Destroi entity
    /// </summary>
    public async Task DestroyEntityAsync(int entityId)
    {
        if (!_entities.TryGetValue(entityId, out var entity))
        {
            Console.WriteLine($"⚠️ Entity {entityId} not found");
            return;
        }
        
        // Remove do JavaScript (Three.js)
        if (_ecsModule is not null)
        {
            await _ecsModule.InvokeVoidAsync("destroyEntity", entityId);
        }
        
        // Remove do cache
        foreach (var cache in _componentCache.Values)
        {
            cache.Remove(entity);
        }
        
        _entities.Remove(entityId);
        OnEntityDestroyed?.Invoke(entity);
        
        Console.WriteLine($"🗑️ Entity destroyed: {entityId}");
    }
    
    /// <summary>
    /// Obtém entity por ID
    /// </summary>
    public Entity? GetEntity(int id)
    {
        return _entities.GetValueOrDefault(id);
    }
    
    /// <summary>
    /// Query: Obtém todas entities com um component específico
    /// </summary>
    public List<Entity> GetEntitiesWithComponent<T>() where T : IComponent
    {
        var type = typeof(T);
        
        // Usa cache se disponível
        if (_componentCache.TryGetValue(type, out var cached))
        {
            return cached;
        }
        
        // Busca e cacheia
        var entities = _entities.Values
            .Where(e => e.HasComponent<T>())
            .ToList();
        
        _componentCache[type] = entities;
        return entities;
    }
    
    /// <summary>
    /// Query: Obtém entities com múltiplos components
    /// </summary>
    public List<Entity> GetEntitiesWithComponents(params Type[] componentTypes)
    {
        return _entities.Values
            .Where(e => componentTypes.All(t => e.GetAllComponents().Any(c => c.GetType() == t)))
            .ToList();
    }
    
    /// <summary>
    /// Limpa cache de queries
    /// </summary>
    public void InvalidateCache()
    {
        _componentCache.Clear();
    }
    
    /// <summary>
    /// Adiciona component e invalida cache
    /// </summary>
    public void AddComponentToEntity<T>(int entityId, T component) where T : IComponent
    {
        var entity = GetEntity(entityId);
        if (entity is null) return;
        
        entity.AddComponent(component);
        InvalidateCache();
    }
    
    /// <summary>
    /// Sincroniza entity com JavaScript (Three.js)
    /// </summary>
    public async Task SyncEntityToJSAsync(Entity entity)
    {
        if (_ecsModule is null) return;
        
        var transform = entity.GetComponent<TransformComponent>();
        var mesh = entity.GetComponent<MeshComponent>();
        
        if (transform is null || mesh is null) return;
        
        await _ecsModule.InvokeVoidAsync("updateEntity", new
        {
            id = entity.Id,
            position = new[] { transform.Position.X, transform.Position.Y, transform.Position.Z },
            rotation = new[] { transform.Rotation.X, transform.Rotation.Y, transform.Rotation.Z },
            scale = new[] { transform.Scale.X, transform.Scale.Y, transform.Scale.Z },
            meshId = mesh.MeshId
        });
    }
    
    /// <summary>
    /// Cria entity IFC completa
    /// </summary>
    public async Task<Entity> CreateIFCEntityAsync(
        int modelId,
        int expressId,
        string ifcType,
        string ifcGuid,
        Vector3 position)
    {
        var entity = CreateEntity($"IFC_{ifcType}_{expressId}");
        
        // Transform
        entity.AddComponent(new TransformComponent(position));
        
        // Mesh (será criado no Three.js)
        entity.AddComponent(new MeshComponent
        {
            MeshId = $"mesh_{modelId}_{expressId}",
            GeometryType = "ifc",
            MaterialType = "standard"
        });
        
        // IFC Data
        entity.AddComponent(new IFCComponent
        {
            ModelId = modelId,
            ExpressId = expressId,
            IfcType = ifcType,
            IfcGuid = ifcGuid
        });
        
        // Visibility
        entity.AddComponent(new VisibilityComponent());
        
        // Bounding Box (será calculado depois)
        entity.AddComponent(new BoundingBoxComponent());
        
        // Sync para JavaScript
        await SyncEntityToJSAsync(entity);
        
        return entity;
    }
    
    /// <summary>
    /// Estatísticas
    /// </summary>
    public ECSStats GetStats()
    {
        return new ECSStats
        {
            TotalEntities = _entities.Count,
            EntitiesWithMesh = GetEntitiesWithComponent<MeshComponent>().Count,
            EntitiesWithIFC = GetEntitiesWithComponent<IFCComponent>().Count,
            CachedQueries = _componentCache.Count
        };
    }
    
    public async ValueTask DisposeAsync()
    {
        if (_ecsModule is not null)
        {
            await _ecsModule.DisposeAsync();
        }
    }
}

/// <summary>
/// Estatísticas do ECS
/// </summary>
public class ECSStats
{
    public int TotalEntities { get; set; }
    public int EntitiesWithMesh { get; set; }
    public int EntitiesWithIFC { get; set; }
    public int CachedQueries { get; set; }
}
