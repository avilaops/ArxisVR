namespace ArxisVR.Client.ECS;

/// <summary>
/// Entity - Objeto único no ECS
/// Apenas um ID, os Components definem comportamento
/// </summary>
public class Entity
{
    public int Id { get; }
    public string Name { get; set; }
    
    // Components attached to this entity
    private readonly Dictionary<Type, IComponent> _components = new();
    
    public Entity(int id, string name = "Entity")
    {
        Id = id;
        Name = name;
    }
    
    /// <summary>
    /// Adiciona component à entity
    /// </summary>
    public void AddComponent<T>(T component) where T : IComponent
    {
        var type = typeof(T);
        if (_components.ContainsKey(type))
        {
            Console.WriteLine($"⚠️ Entity {Id} already has {type.Name}");
            return;
        }
        
        _components[type] = component;
    }
    
    /// <summary>
    /// Remove component da entity
    /// </summary>
    public void RemoveComponent<T>() where T : IComponent
    {
        _components.Remove(typeof(T));
    }
    
    /// <summary>
    /// Obtém component específico
    /// </summary>
    public T? GetComponent<T>() where T : IComponent
    {
        if (_components.TryGetValue(typeof(T), out var component))
        {
            return (T)component;
        }
        return default;
    }
    
    /// <summary>
    /// Verifica se entity tem component
    /// </summary>
    public bool HasComponent<T>() where T : IComponent
    {
        return _components.ContainsKey(typeof(T));
    }
    
    /// <summary>
    /// Obtém todos components
    /// </summary>
    public IEnumerable<IComponent> GetAllComponents()
    {
        return _components.Values;
    }
    
    public override string ToString()
    {
        return $"Entity {Id} ({Name}) - Components: {_components.Count}";
    }
}
