namespace ArxisVR.Client.ECS;

/// <summary>
/// Interface base para todos Components
/// </summary>
public interface IComponent { }

/// <summary>
/// TransformComponent - Posição, rotação, escala
/// </summary>
public class TransformComponent : IComponent
{
    public Vector3 Position { get; set; } = new();
    public Vector3 Rotation { get; set; } = new();
    public Vector3 Scale { get; set; } = new(1, 1, 1);
    
    public TransformComponent() { }
    
    public TransformComponent(Vector3 position)
    {
        Position = position;
    }
    
    public TransformComponent(Vector3 position, Vector3 rotation, Vector3 scale)
    {
        Position = position;
        Rotation = rotation;
        Scale = scale;
    }
}

/// <summary>
/// MeshComponent - Geometria e material (referência para Three.js)
/// </summary>
public class MeshComponent : IComponent
{
    public string MeshId { get; set; } = string.Empty; // ID no Three.js
    public string GeometryType { get; set; } = "box";
    public string MaterialType { get; set; } = "standard";
    public bool CastShadow { get; set; } = true;
    public bool ReceiveShadow { get; set; } = true;
}

/// <summary>
/// IFCComponent - Dados IFC específicos
/// </summary>
public class IFCComponent : IComponent
{
    public int ModelId { get; set; }
    public int ExpressId { get; set; }
    public string IfcType { get; set; } = string.Empty;
    public string IfcGuid { get; set; } = string.Empty;
    public Dictionary<string, object> Properties { get; set; } = new();
}

/// <summary>
/// LODComponent - Level of Detail
/// </summary>
public class LODComponent : IComponent
{
    public int CurrentLevel { get; set; } = 0; // 0 = highest detail
    public List<LODLevel> Levels { get; set; } = new();
}

public class LODLevel
{
    public int Level { get; set; }
    public double Distance { get; set; }
    public string MeshId { get; set; } = string.Empty;
    public int TriangleCount { get; set; }
}

/// <summary>
/// VisibilityComponent - Controle de visibilidade
/// </summary>
public class VisibilityComponent : IComponent
{
    public bool Visible { get; set; } = true;
    public bool FrustumCulled { get; set; } = false;
    public bool OcclusionCulled { get; set; } = false;
    public string LayerId { get; set; } = string.Empty;
}

/// <summary>
/// BoundingBoxComponent - Caixa delimitadora
/// </summary>
public class BoundingBoxComponent : IComponent
{
    public Vector3 Min { get; set; } = new();
    public Vector3 Max { get; set; } = new();
    public Vector3 Center { get; set; } = new();
    public Vector3 Size { get; set; } = new();
}

/// <summary>
/// Vector3 helper
/// </summary>
public class Vector3
{
    public double X { get; set; }
    public double Y { get; set; }
    public double Z { get; set; }
    
    public Vector3() { }
    
    public Vector3(double x, double y, double z)
    {
        X = x;
        Y = y;
        Z = z;
    }
    
    public override string ToString() => $"({X:F2}, {Y:F2}, {Z:F2})";
}
