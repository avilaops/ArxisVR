using Microsoft.JSInterop;

namespace ArxisVR.Client.Services;

/// <summary>
/// Service para comunicação com Three.js via JSInterop
/// Bridge entre Blazor e Engine 3D JavaScript
/// </summary>
public class ViewerService
{
    private readonly IJSRuntime _jsRuntime;
    private IJSObjectReference? _viewerModule;
    
    public ViewerService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }
    
    /// <summary>
    /// Inicializa o viewer Three.js
    /// </summary>
    public async Task InitializeAsync(string canvasId)
    {
        _viewerModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/viewer.js");
            
        await _viewerModule.InvokeVoidAsync("initViewer", canvasId);
    }
    
    /// <summary>
    /// Carrega arquivo IFC
    /// </summary>
    public async Task LoadIFCAsync(string fileUrl)
    {
        if (_viewerModule is null)
            throw new InvalidOperationException("Viewer not initialized");
            
        await _viewerModule.InvokeVoidAsync("loadIFC", fileUrl);
    }
    
    /// <summary>
    /// Muda modo de navegação
    /// </summary>
    public async Task SetNavigationModeAsync(string mode)
    {
        if (_viewerModule is null) return;
        await _viewerModule.InvokeVoidAsync("setNavigationMode", mode);
    }
    
    /// <summary>
    /// Seleciona elemento pelo GUID
    /// </summary>
    public async Task SelectElementAsync(string guid)
    {
        if (_viewerModule is null) return;
        await _viewerModule.InvokeVoidAsync("selectElement", guid);
    }
    
    /// <summary>
    /// Aplica clipping plane
    /// </summary>
    public async Task SetClippingPlaneAsync(string axis, double position)
    {
        if (_viewerModule is null) return;
        await _viewerModule.InvokeVoidAsync("setClippingPlane", axis, position);
    }
    
    public async ValueTask DisposeAsync()
    {
        if (_viewerModule is not null)
        {
            await _viewerModule.DisposeAsync();
        }
    }
}
