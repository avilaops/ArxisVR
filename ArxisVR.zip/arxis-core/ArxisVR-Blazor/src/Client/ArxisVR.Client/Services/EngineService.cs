using Microsoft.JSInterop;

namespace ArxisVR.Client.Services;

/// <summary>
/// EngineService - Engine 3D próprio (Three.js + WebGPU + Arxis-Core)
/// Orquestra: Render (Three.js/WebGPU) + Physics (Arxis-Core Rust/WASM)
/// </summary>
public class EngineService
{
    private readonly IJSRuntime _jsRuntime;
    private IJSObjectReference? _engineModule;
    
    // Sub-systems
    private readonly SceneService _sceneService;
    private readonly CameraService _cameraService;
    private readonly InputService _inputService;
    
    // Engine State
    public bool IsInitialized { get; private set; }
    public bool IsWebGPUSupported { get; private set; }
    public EngineMode CurrentMode { get; private set; } = EngineMode.WebGL2;
    public EngineStats Stats { get; private set; } = new();
    
    // Events
    public event Action<EngineStats>? OnStatsUpdated;
    
    public EngineService(
        IJSRuntime jsRuntime,
        SceneService sceneService,
        CameraService cameraService,
        InputService inputService)
    {
        _jsRuntime = jsRuntime;
        _sceneService = sceneService;
        _cameraService = cameraService;
        _inputService = inputService;
    }
    
    /// <summary>
    /// Inicializa o Engine completo
    /// </summary>
    public async Task InitializeAsync(string canvasId)
    {
        try
        {
            Console.WriteLine("🚀 Initializing ArxisVR Engine...");
            
            // Carrega módulo JavaScript do engine
            _engineModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
                "import", "./js/engine.js");
            
            // Detecta suporte WebGPU
            IsWebGPUSupported = await _engineModule.InvokeAsync<bool>("detectWebGPU");
            
            if (IsWebGPUSupported)
            {
                Console.WriteLine("✅ WebGPU supported! Using WebGPU renderer");
                CurrentMode = EngineMode.WebGPU;
            }
            else
            {
                Console.WriteLine("⚠️ WebGPU not supported. Falling back to WebGL2");
                CurrentMode = EngineMode.WebGL2;
            }
            
            // Inicializa Arxis-Core (Rust WASM)
            await InitializeArxisCoreAsync();
            
            // Inicializa engine principal
            await _engineModule.InvokeVoidAsync("initializeEngine", canvasId, CurrentMode.ToString().ToLower());
            
            // Inicializa sub-systems
            await _sceneService.InitializeAsync();
            await _cameraService.InitializeAsync();
            await _inputService.InitializeAsync(canvasId);
            
            IsInitialized = true;
            Console.WriteLine("✅ ArxisVR Engine initialized successfully!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ Engine initialization failed: {ex.Message}");
            throw;
        }
    }
    
    /// <summary>
    /// Inicializa Arxis-Core (Rust WASM)
    /// </summary>
    private async Task InitializeArxisCoreAsync()
    {
        try
        {
            Console.WriteLine("🦀 Loading Arxis-Core (Rust WASM)...");
            
            if (_engineModule is null) return;
            
            // Carrega WASM do Arxis-Core
            await _engineModule.InvokeVoidAsync("loadArxisCore");
            
            Console.WriteLine("✅ Arxis-Core loaded!");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"⚠️ Arxis-Core not available: {ex.Message}");
            // Engine continua funcionando sem Arxis-Core (modo degradado)
        }
    }
    
    /// <summary>
    /// Atualiza estatísticas do engine
    /// </summary>
    public async Task UpdateStatsAsync()
    {
        if (_engineModule is null) return;
        
        var statsJson = await _engineModule.InvokeAsync<string>("getEngineStats");
        // TODO: Parse JSON to Stats object
        OnStatsUpdated?.Invoke(Stats);
    }
    
    /// <summary>
    /// Muda modo de renderização (WebGL2 ↔ WebGPU)
    /// </summary>
    public async Task SetRenderModeAsync(EngineMode mode)
    {
        if (_engineModule is null) return;
        
        if (mode == EngineMode.WebGPU && !IsWebGPUSupported)
        {
            Console.WriteLine("⚠️ WebGPU not supported, staying on WebGL2");
            return;
        }
        
        CurrentMode = mode;
        await _engineModule.InvokeVoidAsync("setRenderMode", mode.ToString().ToLower());
        Console.WriteLine($"✅ Render mode changed to {mode}");
    }
    
    /// <summary>
    /// Calcula física usando Arxis-Core (Rust)
    /// </summary>
    public async Task<PhysicsResult?> ComputePhysicsAsync(PhysicsInput input)
    {
        if (_engineModule is null) return null;
        
        try
        {
            var resultJson = await _engineModule.InvokeAsync<string>(
                "computePhysics",
                System.Text.Json.JsonSerializer.Serialize(input)
            );
            
            return System.Text.Json.JsonSerializer.Deserialize<PhysicsResult>(resultJson);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"⚠️ Physics computation failed: {ex.Message}");
            return null;
        }
    }
    
    public async ValueTask DisposeAsync()
    {
        if (_engineModule is not null)
        {
            await _engineModule.InvokeVoidAsync("dispose");
            await _engineModule.DisposeAsync();
        }
    }
}

/// <summary>
/// Modos de renderização
/// </summary>
public enum EngineMode
{
    WebGL2,
    WebGPU
}

/// <summary>
/// Estatísticas do engine
/// </summary>
public class EngineStats
{
    public int FPS { get; set; }
    public int DrawCalls { get; set; }
    public int Triangles { get; set; }
    public long MemoryUsed { get; set; }
    public double FrameTime { get; set; }
}

/// <summary>
/// Input para cálculos de física
/// </summary>
public class PhysicsInput
{
    public double[] Position { get; set; } = Array.Empty<double>();
    public double[] Velocity { get; set; } = Array.Empty<double>();
    public double Mass { get; set; }
}

/// <summary>
/// Resultado de cálculos de física
/// </summary>
public class PhysicsResult
{
    public double[] NewPosition { get; set; } = Array.Empty<double>();
    public double[] NewVelocity { get; set; } = Array.Empty<double>();
    public double[] Force { get; set; } = Array.Empty<double>();
}
