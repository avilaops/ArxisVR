using Microsoft.JSInterop;
using System.Text.Json;

namespace ArxisVR.Client.Services;

/// <summary>
/// WorkerService - Gerenciador de Web Workers (Multithread)
/// Processa IFC parsing e geometria em background
/// </summary>
public class WorkerService
{
    private readonly IJSRuntime _jsRuntime;
    private IJSObjectReference? _workerModule;
    private readonly DotNetObjectReference<WorkerService> _dotNetRef;
    
    // Workers ativos
    private readonly Dictionary<string, WorkerInfo> _workers = new();
    
    // Events
    public event Action<string, string>? OnWorkerMessage;
    public event Action<string, double>? OnWorkerProgress;
    public event Action<string, string>? OnWorkerError;
    
    public WorkerService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
        _dotNetRef = DotNetObjectReference.Create(this);
    }
    
    /// <summary>
    /// Inicializa Worker Manager
    /// </summary>
    public async Task InitializeAsync()
    {
        _workerModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/worker-manager.js");
            
        await _workerModule.InvokeVoidAsync("initializeWorkerManager", _dotNetRef);
        Console.WriteLine("✅ Worker Service initialized");
    }
    
    /// <summary>
    /// Cria novo worker
    /// </summary>
    public async Task<string> CreateWorkerAsync(WorkerType type)
    {
        if (_workerModule is null)
            throw new InvalidOperationException("Worker module not initialized");
        
        var workerId = Guid.NewGuid().ToString();
        var workerPath = GetWorkerPath(type);
        
        await _workerModule.InvokeVoidAsync("createWorker", workerId, workerPath);
        
        _workers[workerId] = new WorkerInfo
        {
            Id = workerId,
            Type = type,
            Status = WorkerStatus.Idle,
            CreatedAt = DateTime.UtcNow
        };
        
        Console.WriteLine($"🔨 Worker created: {workerId} ({type})");
        return workerId;
    }
    
    /// <summary>
    /// Envia tarefa para worker
    /// </summary>
    public async Task<string?> PostTaskAsync<T>(string workerId, string taskType, T data)
    {
        if (_workerModule is null || !_workers.ContainsKey(workerId))
            return null;
        
        var worker = _workers[workerId];
        worker.Status = WorkerStatus.Busy;
        worker.CurrentTask = taskType;
        
        var taskId = Guid.NewGuid().ToString();
        var json = JsonSerializer.Serialize(data);
        
        await _workerModule.InvokeVoidAsync("postTask", workerId, taskId, taskType, json);
        
        Console.WriteLine($"📤 Task sent to worker {workerId}: {taskType}");
        return taskId;
    }
    
    /// <summary>
    /// Parse IFC em worker (background)
    /// </summary>
    public async Task<string?> ParseIFCInWorkerAsync(byte[] ifcData, string fileName)
    {
        // Cria worker específico para IFC
        var workerId = await CreateWorkerAsync(WorkerType.IFCParser);
        
        // Converte para base64
        var base64 = Convert.ToBase64String(ifcData);
        
        // Envia para worker
        return await PostTaskAsync(workerId, "parse_ifc", new
        {
            fileName,
            data = base64
        });
    }
    
    /// <summary>
    /// Processa geometria em worker
    /// </summary>
    public async Task<string?> ProcessGeometryInWorkerAsync(string geometryData)
    {
        var workerId = await CreateWorkerAsync(WorkerType.GeometryProcessor);
        
        return await PostTaskAsync(workerId, "process_geometry", new
        {
            geometry = geometryData
        });
    }
    
    /// <summary>
    /// Calcula LOD em worker
    /// </summary>
    public async Task<string?> CalculateLODInWorkerAsync(int modelId, int[] expressIds)
    {
        var workerId = await CreateWorkerAsync(WorkerType.LODCalculator);
        
        return await PostTaskAsync(workerId, "calculate_lod", new
        {
            modelId,
            expressIds
        });
    }
    
    /// <summary>
    /// Termina worker
    /// </summary>
    public async Task TerminateWorkerAsync(string workerId)
    {
        if (_workerModule is null || !_workers.ContainsKey(workerId))
            return;
        
        await _workerModule.InvokeVoidAsync("terminateWorker", workerId);
        _workers.Remove(workerId);
        
        Console.WriteLine($"🗑️ Worker terminated: {workerId}");
    }
    
    /// <summary>
    /// Termina todos workers
    /// </summary>
    public async Task TerminateAllWorkersAsync()
    {
        var workerIds = _workers.Keys.ToList();
        foreach (var workerId in workerIds)
        {
            await TerminateWorkerAsync(workerId);
        }
    }
    
    /// <summary>
    /// Callbacks do JavaScript
    /// </summary>
    [JSInvokable]
    public void OnWorkerMessageFromJS(string workerId, string message)
    {
        if (_workers.TryGetValue(workerId, out var worker))
        {
            worker.Status = WorkerStatus.Idle;
            worker.CurrentTask = null;
        }
        
        OnWorkerMessage?.Invoke(workerId, message);
    }
    
    [JSInvokable]
    public void OnWorkerProgressFromJS(string workerId, double progress)
    {
        OnWorkerProgress?.Invoke(workerId, progress);
    }
    
    [JSInvokable]
    public void OnWorkerErrorFromJS(string workerId, string error)
    {
        if (_workers.TryGetValue(workerId, out var worker))
        {
            worker.Status = WorkerStatus.Error;
            worker.LastError = error;
        }
        
        OnWorkerError?.Invoke(workerId, error);
        Console.WriteLine($"❌ Worker error {workerId}: {error}");
    }
    
    /// <summary>
    /// Estatísticas
    /// </summary>
    public WorkerStats GetStats()
    {
        return new WorkerStats
        {
            TotalWorkers = _workers.Count,
            IdleWorkers = _workers.Count(w => w.Value.Status == WorkerStatus.Idle),
            BusyWorkers = _workers.Count(w => w.Value.Status == WorkerStatus.Busy),
            ErrorWorkers = _workers.Count(w => w.Value.Status == WorkerStatus.Error)
        };
    }
    
    private string GetWorkerPath(WorkerType type)
    {
        return type switch
        {
            WorkerType.IFCParser => "./workers/ifc-parser.worker.js",
            WorkerType.GeometryProcessor => "./workers/geometry.worker.js",
            WorkerType.LODCalculator => "./workers/lod.worker.js",
            WorkerType.Physics => "./workers/physics.worker.js",
            _ => throw new ArgumentException($"Unknown worker type: {type}")
        };
    }
    
    public async ValueTask DisposeAsync()
    {
        await TerminateAllWorkersAsync();
        
        if (_workerModule is not null)
        {
            await _workerModule.DisposeAsync();
        }
        
        _dotNetRef.Dispose();
    }
}

/// <summary>
/// Tipos de workers
/// </summary>
public enum WorkerType
{
    IFCParser,
    GeometryProcessor,
    LODCalculator,
    Physics
}

/// <summary>
/// Status do worker
/// </summary>
public enum WorkerStatus
{
    Idle,
    Busy,
    Error
}

/// <summary>
/// Informações do worker
/// </summary>
public class WorkerInfo
{
    public string Id { get; set; } = string.Empty;
    public WorkerType Type { get; set; }
    public WorkerStatus Status { get; set; }
    public string? CurrentTask { get; set; }
    public string? LastError { get; set; }
    public DateTime CreatedAt { get; set; }
}

/// <summary>
/// Estatísticas dos workers
/// </summary>
public class WorkerStats
{
    public int TotalWorkers { get; set; }
    public int IdleWorkers { get; set; }
    public int BusyWorkers { get; set; }
    public int ErrorWorkers { get; set; }
}
