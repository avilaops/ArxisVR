using Microsoft.AspNetCore.Components.Forms;
using Microsoft.JSInterop;
using System.Text.Json;

namespace ArxisVR.Client.Services;

/// <summary>
/// IFCService - Carregamento e processamento de arquivos IFC
/// Migrado de: src/loaders/IFCLoader.ts
/// </summary>
public class IFCService
{
    private readonly IJSRuntime _jsRuntime;
    private readonly HttpClient _httpClient;
    private IJSObjectReference? _ifcModule;
    
    // State
    public bool IsLoading { get; private set; }
    public double LoadProgress { get; private set; }
    public string? CurrentFileName { get; private set; }
    public List<IFCModel> LoadedModels { get; } = new();
    
    // Events
    public event Action<double>? OnLoadProgress;
    public event Action<IFCModel>? OnModelLoaded;
    public event Action<string>? OnLoadError;
    
    // Configurações
    public IFCLoadConfig Config { get; set; } = new();
    
    public IFCService(IJSRuntime jsRuntime, HttpClient httpClient)
    {
        _jsRuntime = jsRuntime;
        _httpClient = httpClient;
    }
    
    /// <summary>
    /// Inicializa o módulo IFC JavaScript
    /// </summary>
    public async Task InitializeAsync()
    {
        _ifcModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/ifc-loader.js");
            
        await _ifcModule.InvokeVoidAsync("initializeIFCLoader");
        Console.WriteLine("✅ IFCService initialized");
    }
    
    /// <summary>
    /// Carrega arquivo IFC do navegador
    /// </summary>
    public async Task<IFCModel?> LoadIFCFromBrowserAsync(IBrowserFile file, long maxFileSize = 500_000_000)
    {
        if (_ifcModule is null)
        {
            Console.WriteLine("❌ IFC module not initialized");
            return null;
        }
        
        try
        {
            IsLoading = true;
            CurrentFileName = file.Name;
            LoadProgress = 0;
            
            Console.WriteLine($"📦 Loading IFC file: {file.Name} ({file.Size / 1024 / 1024:F2} MB)");
            
            // Cria stream do arquivo
            using var stream = file.OpenReadStream(maxFileSize);
            using var memoryStream = new MemoryStream();
            await stream.CopyToAsync(memoryStream);
            var fileData = memoryStream.ToArray();
            
            // Converte para base64 para passar ao JavaScript
            var base64 = Convert.ToBase64String(fileData);
            
            // Chama JavaScript para processar
            var modelJson = await _ifcModule.InvokeAsync<string>(
                "loadIFCFromBase64", 
                file.Name, 
                base64,
                DotNetObjectReference.Create(this)
            );
            
            var model = JsonSerializer.Deserialize<IFCModel>(modelJson);
            
            if (model != null)
            {
                model.FileName = file.Name;
                model.LoadedAt = DateTime.UtcNow;
                LoadedModels.Add(model);
                
                Console.WriteLine($"✅ IFC loaded: {model.ElementCount} elements");
                OnModelLoaded?.Invoke(model);
            }
            
            return model;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ Error loading IFC: {ex.Message}");
            OnLoadError?.Invoke(ex.Message);
            return null;
        }
        finally
        {
            IsLoading = false;
            CurrentFileName = null;
            LoadProgress = 0;
        }
    }
    
    /// <summary>
    /// Carrega arquivo IFC de URL
    /// </summary>
    public async Task<IFCModel?> LoadIFCFromUrlAsync(string url)
    {
        if (_ifcModule is null) return null;
        
        try
        {
            IsLoading = true;
            LoadProgress = 0;
            
            Console.WriteLine($"📦 Loading IFC from URL: {url}");
            
            var modelJson = await _ifcModule.InvokeAsync<string>(
                "loadIFCFromUrl",
                url,
                DotNetObjectReference.Create(this)
            );
            
            var model = JsonSerializer.Deserialize<IFCModel>(modelJson);
            
            if (model != null)
            {
                model.FileName = Path.GetFileName(url);
                model.LoadedAt = DateTime.UtcNow;
                LoadedModels.Add(model);
                OnModelLoaded?.Invoke(model);
            }
            
            return model;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ Error: {ex.Message}");
            OnLoadError?.Invoke(ex.Message);
            return null;
        }
        finally
        {
            IsLoading = false;
            LoadProgress = 0;
        }
    }
    
    /// <summary>
    /// Chamado do JavaScript para atualizar progresso
    /// </summary>
    [JSInvokable]
    public void UpdateProgress(double progress)
    {
        LoadProgress = progress;
        OnLoadProgress?.Invoke(progress);
    }
    
    /// <summary>
    /// Obtém propriedades de um elemento IFC
    /// </summary>
    public async Task<IFCProperties?> GetElementPropertiesAsync(int modelId, int expressId)
    {
        if (_ifcModule is null) return null;
        
        var json = await _ifcModule.InvokeAsync<string>(
            "getElementProperties", 
            modelId, 
            expressId
        );
        
        return JsonSerializer.Deserialize<IFCProperties>(json);
    }
    
    /// <summary>
    /// Obtém todos os elementos de um tipo IFC
    /// </summary>
    public async Task<List<int>> GetElementsByTypeAsync(int modelId, string ifcType)
    {
        if (_ifcModule is null) return new();
        
        var json = await _ifcModule.InvokeAsync<string>(
            "getElementsByType",
            modelId,
            ifcType
        );
        
        return JsonSerializer.Deserialize<List<int>>(json) ?? new();
    }
    
    /// <summary>
    /// Remove modelo carregado
    /// </summary>
    public async Task UnloadModelAsync(int modelId)
    {
        if (_ifcModule is null) return;
        
        await _ifcModule.InvokeVoidAsync("unloadModel", modelId);
        LoadedModels.RemoveAll(m => m.ModelId == modelId);
    }
    
    public async ValueTask DisposeAsync()
    {
        if (_ifcModule is not null)
        {
            await _ifcModule.DisposeAsync();
        }
    }
}

/// <summary>
/// Modelo IFC carregado
/// </summary>
public class IFCModel
{
    public int ModelId { get; set; }
    public string? FileName { get; set; }
    public DateTime LoadedAt { get; set; }
    public int ElementCount { get; set; }
    public BoundingBox Bounds { get; set; } = new();
    public Dictionary<string, int> ElementsByType { get; set; } = new();
}

/// <summary>
/// Bounding box do modelo
/// </summary>
public class BoundingBox
{
    public Vector3D Min { get; set; } = new();
    public Vector3D Max { get; set; } = new();
    public Vector3D Center { get; set; } = new();
    public Vector3D Size { get; set; } = new();
}

/// <summary>
/// Vetor 3D
/// </summary>
public class Vector3D
{
    public double X { get; set; }
    public double Y { get; set; }
    public double Z { get; set; }
}

/// <summary>
/// Propriedades de elemento IFC
/// </summary>
public class IFCProperties
{
    public int ExpressId { get; set; }
    public string Type { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public Dictionary<string, object> Properties { get; set; } = new();
    public Dictionary<string, Dictionary<string, object>> PropertySets { get; set; } = new();
}

/// <summary>
/// Configurações de carregamento IFC
/// </summary>
public class IFCLoadConfig
{
    public bool CoordinateToOrigin { get; set; } = true;
    public bool UseFastBools { get; set; } = true;
    public bool OptimizeGeometry { get; set; } = true;
    public bool CreateLayers { get; set; } = true;
}
