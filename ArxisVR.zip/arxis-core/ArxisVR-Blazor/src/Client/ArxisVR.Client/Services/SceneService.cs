using Microsoft.JSInterop;

namespace ArxisVR.Client.Services;

/// <summary>
/// SceneService - Gerenciador da cena 3D
/// Migrado de: src/engine/SceneManager.ts
/// </summary>
public class SceneService
{
    private readonly IJSRuntime _jsRuntime;
    private IJSObjectReference? _sceneModule;
    
    // State
    public bool IsGridVisible { get; private set; } = true;
    public bool IsAxesVisible { get; private set; } = true;
    public int BackgroundColor { get; private set; } = 0x87ceeb;
    
    // Events
    public event Action? OnSceneChanged;
    
    public SceneService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }
    
    /// <summary>
    /// Inicializa o módulo de cena JavaScript
    /// </summary>
    public async Task InitializeAsync()
    {
        _sceneModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/scene.js");
            
        await _sceneModule.InvokeVoidAsync("initializeScene");
        Console.WriteLine("✅ SceneService initialized");
    }
    
    /// <summary>
    /// Define cor de fundo da cena
    /// </summary>
    public async Task SetBackgroundColorAsync(int color)
    {
        if (_sceneModule is null) return;
        
        BackgroundColor = color;
        await _sceneModule.InvokeVoidAsync("setBackgroundColor", color);
        OnSceneChanged?.Invoke();
    }
    
    /// <summary>
    /// Define distância do fog (neblina)
    /// </summary>
    public async Task SetFogDistanceAsync(double near, double far)
    {
        if (_sceneModule is null) return;
        await _sceneModule.InvokeVoidAsync("setFogDistance", near, far);
    }
    
    /// <summary>
    /// Toggle visibilidade do grid
    /// </summary>
    public async Task ToggleGridAsync()
    {
        if (_sceneModule is null) return;
        
        IsGridVisible = !IsGridVisible;
        await _sceneModule.InvokeVoidAsync("toggleGrid");
        OnSceneChanged?.Invoke();
    }
    
    /// <summary>
    /// Toggle visibilidade dos axes
    /// </summary>
    public async Task ToggleAxesAsync()
    {
        if (_sceneModule is null) return;
        
        IsAxesVisible = !IsAxesVisible;
        await _sceneModule.InvokeVoidAsync("toggleAxes");
        OnSceneChanged?.Invoke();
    }
    
    /// <summary>
    /// Adiciona objeto à cena (via serialização JSON)
    /// </summary>
    public async Task AddObjectAsync(string objectJson)
    {
        if (_sceneModule is null) return;
        await _sceneModule.InvokeVoidAsync("addObject", objectJson);
    }
    
    /// <summary>
    /// Remove objeto da cena
    /// </summary>
    public async Task RemoveObjectAsync(string objectId)
    {
        if (_sceneModule is null) return;
        await _sceneModule.InvokeVoidAsync("removeObject", objectId);
    }
    
    /// <summary>
    /// Limpa toda a cena
    /// </summary>
    public async Task ClearSceneAsync()
    {
        if (_sceneModule is null) return;
        await _sceneModule.InvokeVoidAsync("clearScene");
        OnSceneChanged?.Invoke();
    }
    
    public async ValueTask DisposeAsync()
    {
        if (_sceneModule is not null)
        {
            await _sceneModule.DisposeAsync();
        }
    }
}
