using Microsoft.JSInterop;

namespace ArxisVR.Client.Services;

/// <summary>
/// InputService - Sistema de entrada (teclado, mouse)
/// Migrado de: src/engine/InputSystem.ts
/// </summary>
public class InputService
{
    private readonly IJSRuntime _jsRuntime;
    private IJSObjectReference? _inputModule;
    private DotNetObjectReference<InputService>? _dotNetRef;
    
    // Input State
    public Dictionary<string, bool> KeysPressed { get; } = new();
    public MouseState Mouse { get; private set; } = new();
    
    // Events
    public event Action<string>? OnKeyDown;
    public event Action<string>? OnKeyUp;
    public event Action<MouseState>? OnMouseMove;
    public event Action<MouseState>? OnMouseClick;
    
    public InputService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }
    
    /// <summary>
    /// Inicializa o sistema de input
    /// </summary>
    public async Task InitializeAsync(string canvasId)
    {
        _dotNetRef = DotNetObjectReference.Create(this);
        
        _inputModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/input.js");
            
        await _inputModule.InvokeVoidAsync("initializeInput", canvasId, _dotNetRef);
        Console.WriteLine("✅ InputService initialized");
    }
    
    /// <summary>
    /// Chamado do JavaScript quando uma tecla é pressionada
    /// </summary>
    [JSInvokable]
    public void OnKeyDownFromJS(string key)
    {
        KeysPressed[key] = true;
        OnKeyDown?.Invoke(key);
    }
    
    /// <summary>
    /// Chamado do JavaScript quando uma tecla é solta
    /// </summary>
    [JSInvokable]
    public void OnKeyUpFromJS(string key)
    {
        KeysPressed[key] = false;
        OnKeyUp?.Invoke(key);
    }
    
    /// <summary>
    /// Chamado do JavaScript quando o mouse se move
    /// </summary>
    [JSInvokable]
    public void OnMouseMoveFromJS(double x, double y, double deltaX, double deltaY)
    {
        Mouse = Mouse with 
        { 
            X = x, 
            Y = y, 
            DeltaX = deltaX, 
            DeltaY = deltaY 
        };
        OnMouseMove?.Invoke(Mouse);
    }
    
    /// <summary>
    /// Chamado do JavaScript quando o mouse é clicado
    /// </summary>
    [JSInvokable]
    public void OnMouseClickFromJS(int button, double x, double y)
    {
        Mouse = Mouse with 
        { 
            X = x, 
            Y = y, 
            Button = button 
        };
        OnMouseClick?.Invoke(Mouse);
    }
    
    /// <summary>
    /// Verifica se uma tecla está pressionada
    /// </summary>
    public bool IsKeyPressed(string key)
    {
        return KeysPressed.GetValueOrDefault(key, false);
    }
    
    /// <summary>
    /// Habilita/Desabilita input de mouse
    /// </summary>
    public async Task SetMouseEnabledAsync(bool enabled)
    {
        if (_inputModule is null) return;
        await _inputModule.InvokeVoidAsync("setMouseEnabled", enabled);
    }
    
    /// <summary>
    /// Habilita/Desabilita input de teclado
    /// </summary>
    public async Task SetKeyboardEnabledAsync(bool enabled)
    {
        if (_inputModule is null) return;
        await _inputModule.InvokeVoidAsync("setKeyboardEnabled", enabled);
    }
    
    public async ValueTask DisposeAsync()
    {
        if (_inputModule is not null)
        {
            await _inputModule.InvokeVoidAsync("dispose");
            await _inputModule.DisposeAsync();
        }
        _dotNetRef?.Dispose();
    }
}

/// <summary>
/// Estado do mouse
/// </summary>
public record MouseState
{
    public double X { get; init; }
    public double Y { get; init; }
    public double DeltaX { get; init; }
    public double DeltaY { get; init; }
    public int Button { get; init; }
}
