using Microsoft.JSInterop;

namespace ArxisVR.Client.Services;

/// <summary>
/// CameraService - Sistema de câmera
/// Migrado de: src/engine/CameraSystem.ts
/// </summary>
public class CameraService
{
    private readonly IJSRuntime _jsRuntime;
    private IJSObjectReference? _cameraModule;
    
    // Camera State
    public CameraPosition Position { get; private set; } = new(0, 5, 10);
    public CameraView CurrentView { get; private set; } = CameraView.Perspective;
    
    // Events
    public event Action? OnCameraChanged;
    
    public CameraService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }
    
    /// <summary>
    /// Inicializa o módulo de câmera JavaScript
    /// </summary>
    public async Task InitializeAsync()
    {
        _cameraModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/camera.js");
            
        await _cameraModule.InvokeVoidAsync("initializeCamera");
        Console.WriteLine("✅ CameraService initialized");
    }
    
    /// <summary>
    /// Define posição da câmera
    /// </summary>
    public async Task SetPositionAsync(double x, double y, double z)
    {
        if (_cameraModule is null) return;
        
        Position = new CameraPosition(x, y, z);
        await _cameraModule.InvokeVoidAsync("setCameraPosition", x, y, z);
        OnCameraChanged?.Invoke();
    }
    
    /// <summary>
    /// Define rotação da câmera
    /// </summary>
    public async Task SetRotationAsync(double x, double y, double z)
    {
        if (_cameraModule is null) return;
        await _cameraModule.InvokeVoidAsync("setCameraRotation", x, y, z);
        OnCameraChanged?.Invoke();
    }
    
    /// <summary>
    /// Muda para uma vista predefinida
    /// </summary>
    public async Task SetViewAsync(CameraView view)
    {
        if (_cameraModule is null) return;
        
        CurrentView = view;
        await _cameraModule.InvokeVoidAsync("setCameraView", view.ToString().ToLower());
        OnCameraChanged?.Invoke();
    }
    
    /// <summary>
    /// Foca na seleção atual
    /// </summary>
    public async Task FocusSelectionAsync()
    {
        if (_cameraModule is null) return;
        await _cameraModule.InvokeVoidAsync("focusSelection");
    }
    
    /// <summary>
    /// Enquadra todos os objetos da cena
    /// </summary>
    public async Task FrameAllAsync()
    {
        if (_cameraModule is null) return;
        await _cameraModule.InvokeVoidAsync("frameAll");
    }
    
    /// <summary>
    /// Define FOV (Field of View)
    /// </summary>
    public async Task SetFOVAsync(double fov)
    {
        if (_cameraModule is null) return;
        await _cameraModule.InvokeVoidAsync("setCameraFOV", fov);
    }
    
    /// <summary>
    /// Obtém posição atual da câmera do JavaScript
    /// </summary>
    public async Task<CameraPosition> GetPositionAsync()
    {
        if (_cameraModule is null) 
            return Position;
            
        var pos = await _cameraModule.InvokeAsync<double[]>("getCameraPosition");
        Position = new CameraPosition(pos[0], pos[1], pos[2]);
        return Position;
    }
    
    public async ValueTask DisposeAsync()
    {
        if (_cameraModule is not null)
        {
            await _cameraModule.DisposeAsync();
        }
    }
}

/// <summary>
/// Posição da câmera
/// </summary>
public record CameraPosition(double X, double Y, double Z);

/// <summary>
/// Vistas predefinidas da câmera
/// </summary>
public enum CameraView
{
    Perspective,
    Top,
    Front,
    Right,
    Left,
    Back,
    Bottom,
    Isometric
}
