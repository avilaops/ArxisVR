namespace ArxisVR.Client.State;

/// <summary>
/// Estado global da aplicação ArxisVR
/// Single Source of Truth para toda a aplicação
/// </summary>
public class AppState
{
    // === VIEWER STATE ===
    public ViewerMode CurrentViewerMode { get; set; } = ViewerMode.Orbital;
    public bool IsVRMode { get; set; }
    public string? SelectedElementGuid { get; set; }
    
    // === PROJECT STATE ===
    public string? CurrentProjectId { get; set; }
    public string? CurrentModelName { get; set; }
    public bool IsModelLoaded { get; set; }
    
    // === TOOL STATE ===
    public ActiveTool CurrentTool { get; set; } = ActiveTool.Navigation;
    
    // === UI STATE ===
    public bool IsLeftPanelVisible { get; set; } = true;
    public bool IsRightInspectorVisible { get; set; } = true;
    public bool IsBottomDockVisible { get; set; }
    
    // === LAYER STATE ===
    public List<string> VisibleLayers { get; set; } = new();
    public Dictionary<string, bool> LayerVisibility { get; set; } = new();
    
    // === BIM 4D STATE ===
    public DateTime? CurrentSimulationDate { get; set; }
    public bool Is4DSimulationRunning { get; set; }
    
    // === BIM 5D STATE ===
    public decimal? CurrentBudget { get; set; }
    public decimal? SpentBudget { get; set; }
    
    // === EVENTS ===
    public event Action? OnStateChanged;
    
    public void NotifyStateChanged() => OnStateChanged?.Invoke();
}

public enum ViewerMode
{
    FPS,
    Orbital,
    Walkthrough,
    Fly,
    TopDown
}

public enum ActiveTool
{
    Navigation,
    Selection,
    Measurement,
    Section,
    Annotation,
    Layer
}
