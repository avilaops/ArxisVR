// input.js - Input management (migrado de InputSystem.ts)

let canvas;
let dotNetRef;
let mouseEnabled = true;
let keyboardEnabled = true;
let mouseState = {
    x: 0,
    y: 0,
    prevX: 0,
    prevY: 0
};

export function initializeInput(canvasId, dotNetReference) {
    canvas = document.getElementById(canvasId);
    dotNetRef = dotNetReference;
    
    if (!canvas) {
        console.error('Canvas not found:', canvasId);
        return;
    }
    
    // Keyboard events
    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('keyup', onKeyUp);
    
    // Mouse events
    canvas.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('mousedown', onMouseClick);
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    
    console.log('✅ Input initialized (JS)');
}

function onKeyDown(event) {
    if (!keyboardEnabled || !dotNetRef) return;
    
    dotNetRef.invokeMethodAsync('OnKeyDownFromJS', event.code);
}

function onKeyUp(event) {
    if (!keyboardEnabled || !dotNetRef) return;
    
    dotNetRef.invokeMethodAsync('OnKeyUpFromJS', event.code);
}

function onMouseMove(event) {
    if (!mouseEnabled || !dotNetRef) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    const deltaX = x - mouseState.x;
    const deltaY = y - mouseState.y;
    
    mouseState.prevX = mouseState.x;
    mouseState.prevY = mouseState.y;
    mouseState.x = x;
    mouseState.y = y;
    
    dotNetRef.invokeMethodAsync('OnMouseMoveFromJS', x, y, deltaX, deltaY);
}

function onMouseClick(event) {
    if (!mouseEnabled || !dotNetRef) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    dotNetRef.invokeMethodAsync('OnMouseClickFromJS', event.button, x, y);
}

export function setMouseEnabled(enabled) {
    mouseEnabled = enabled;
}

export function setKeyboardEnabled(enabled) {
    keyboardEnabled = enabled;
}

export function dispose() {
    document.removeEventListener('keydown', onKeyDown);
    document.removeEventListener('keyup', onKeyUp);
    if (canvas) {
        canvas.removeEventListener('mousemove', onMouseMove);
        canvas.removeEventListener('mousedown', onMouseClick);
    }
}
