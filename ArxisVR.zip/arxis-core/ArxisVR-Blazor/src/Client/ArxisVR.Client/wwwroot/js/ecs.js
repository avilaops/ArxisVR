// ecs.js - ECS JavaScript integration
import { getScene } from './scene.js';
import * as THREE from 'three';

// Entity storage (mirror do C#)
const entities = new Map();

export function initializeECS() {
    console.log('✅ ECS JavaScript initialized');
}

/**
 * Cria ou atualiza entity no Three.js
 */
export function updateEntity(entityData) {
    const { id, position, rotation, scale, meshId } = entityData;
    
    let object = entities.get(id);
    
    if (!object) {
        // Cria novo Object3D
        object = new THREE.Group();
        object.name = `Entity_${id}`;
        object.userData.entityId = id;
        
        const scene = getScene();
        scene.add(object);
        entities.set(id, object);
        
        console.log(`🆕 Entity ${id} created in Three.js`);
    }
    
    // Atualiza transform
    if (position) {
        object.position.set(position[0], position[1], position[2]);
    }
    
    if (rotation) {
        object.rotation.set(rotation[0], rotation[1], rotation[2]);
    }
    
    if (scale) {
        object.scale.set(scale[0], scale[1], scale[2]);
    }
}

/**
 * Adiciona mesh à entity
 */
export function addMeshToEntity(entityId, geometry, material) {
    const entity = entities.get(entityId);
    if (!entity) {
        console.warn(`Entity ${entityId} not found`);
        return;
    }
    
    const mesh = new THREE.Mesh(geometry, material);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    
    entity.add(mesh);
}

/**
 * Destroi entity
 */
export function destroyEntity(entityId) {
    const object = entities.get(entityId);
    if (!object) return;
    
    const scene = getScene();
    scene.remove(object);
    
    // Dispose geometries e materials
    object.traverse(child => {
        if (child.isMesh) {
            child.geometry?.dispose();
            child.material?.dispose();
        }
    });
    
    entities.delete(entityId);
    console.log(`🗑️ Entity ${entityId} destroyed from Three.js`);
}

/**
 * Obtém entity do Three.js
 */
export function getEntity(entityId) {
    return entities.get(entityId);
}

/**
 * Atualiza visibilidade
 */
export function setEntityVisibility(entityId, visible) {
    const entity = entities.get(entityId);
    if (entity) {
        entity.visible = visible;
    }
}

/**
 * Calcula bounding box
 */
export function calculateBoundingBox(entityId) {
    const entity = entities.get(entityId);
    if (!entity) return null;
    
    const box = new THREE.Box3().setFromObject(entity);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    
    return {
        min: [box.min.x, box.min.y, box.min.z],
        max: [box.max.x, box.max.y, box.max.z],
        center: [center.x, center.y, center.z],
        size: [size.x, size.y, size.z]
    };
}

/**
 * Query: entities visíveis
 */
export function getVisibleEntities() {
    return Array.from(entities.entries())
        .filter(([_, obj]) => obj.visible)
        .map(([id, _]) => id);
}

/**
 * Estatísticas
 */
export function getECSStats() {
    let meshCount = 0;
    let triangleCount = 0;
    
    entities.forEach(entity => {
        entity.traverse(child => {
            if (child.isMesh) {
                meshCount++;
                if (child.geometry) {
                    triangleCount += (child.geometry.index?.count || 0) / 3;
                }
            }
        });
    });
    
    return {
        entityCount: entities.size,
        meshCount,
        triangleCount
    };
}
