// worker-manager.js - Gerenciador de Web Workers
let dotNetRef = null;
const workers = new Map();

export function initializeWorkerManager(dotNetReference) {
    dotNetRef = dotNetReference;
    console.log('✅ Worker Manager initialized');
}

/**
 * Cria novo worker
 */
export function createWorker(workerId, workerPath) {
    try {
        const worker = new Worker(workerPath, { type: 'module' });
        
        // Message handler
        worker.onmessage = (event) => {
            handleWorkerMessage(workerId, event.data);
        };
        
        // Error handler
        worker.onerror = (error) => {
            console.error(`Worker ${workerId} error:`, error);
            if (dotNetRef) {
                dotNetRef.invokeMethodAsync('OnWorkerErrorFromJS', workerId, error.message);
            }
        };
        
        workers.set(workerId, worker);
        console.log(`🔨 Worker created: ${workerId}`);
    } catch (error) {
        console.error(`Failed to create worker ${workerId}:`, error);
        throw error;
    }
}

/**
 * Envia tarefa para worker
 */
export function postTask(workerId, taskId, taskType, dataJson) {
    const worker = workers.get(workerId);
    if (!worker) {
        console.error(`Worker ${workerId} not found`);
        return;
    }
    
    worker.postMessage({
        taskId,
        type: taskType,
        data: JSON.parse(dataJson)
    });
}

/**
 * Handler de mensagens do worker
 */
function handleWorkerMessage(workerId, message) {
    const { type, data, progress, error } = message;
    
    if (error) {
        // Error
        if (dotNetRef) {
            dotNetRef.invokeMethodAsync('OnWorkerErrorFromJS', workerId, error);
        }
    } else if (progress !== undefined) {
        // Progress update
        if (dotNetRef) {
            dotNetRef.invokeMethodAsync('OnWorkerProgressFromJS', workerId, progress);
        }
    } else {
        // Result
        const resultJson = JSON.stringify(data);
        if (dotNetRef) {
            dotNetRef.invokeMethodAsync('OnWorkerMessageFromJS', workerId, resultJson);
        }
    }
}

/**
 * Termina worker
 */
export function terminateWorker(workerId) {
    const worker = workers.get(workerId);
    if (worker) {
        worker.terminate();
        workers.delete(workerId);
        console.log(`🗑️ Worker terminated: ${workerId}`);
    }
}

/**
 * Termina todos workers
 */
export function terminateAllWorkers() {
    workers.forEach((worker, workerId) => {
        worker.terminate();
        console.log(`🗑️ Worker terminated: ${workerId}`);
    });
    workers.clear();
}

/**
 * Estatísticas
 */
export function getWorkerStats() {
    return {
        activeWorkers: workers.size
    };
}
