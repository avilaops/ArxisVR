// instancing-system.js - GPU Instancing para performance
import * as THREE from 'three';
import { getScene } from './scene.js';

const instancedMeshes = new Map();

export function initializeInstancing() {
    console.log('✅ Instancing System initialized');
}

/**
 * Cria InstancedMesh
 */
export function createInstancedMesh(geometryKey, geometryType, maxInstances) {
    // Cria geometria base
    let geometry;
    switch (geometryType) {
        case 'box':
            geometry = new THREE.BoxGeometry(1, 1, 1);
            break;
        case 'sphere':
            geometry = new THREE.SphereGeometry(0.5, 16, 16);
            break;
        case 'cylinder':
            geometry = new THREE.CylinderGeometry(0.5, 0.5, 1, 16);
            break;
        default:
            geometry = new THREE.BoxGeometry(1, 1, 1);
    }
    
    // Material padrão
    const material = new THREE.MeshStandardMaterial({
        color: 0x808080,
        metalness: 0.1,
        roughness: 0.8
    });
    
    // Cria InstancedMesh
    const instancedMesh = new THREE.InstancedMesh(geometry, material, maxInstances);
    instancedMesh.name = `InstancedMesh_${geometryKey}`;
    instancedMesh.castShadow = true;
    instancedMesh.receiveShadow = true;
    
    // Adiciona à cena
    const scene = getScene();
    scene.add(instancedMesh);
    
    // Armazena
    instancedMeshes.set(geometryKey, {
        mesh: instancedMesh,
        count: 0,
        maxInstances
    });
    
    console.log(`📦 Created InstancedMesh for '${geometryKey}' (max ${maxInstances})`);
}

/**
 * Adiciona instância
 */
export function addInstance(data) {
    const { geometryKey, instanceId, position, rotation, scale } = data;
    
    const group = instancedMeshes.get(geometryKey);
    if (!group) {
        console.error(`InstancedMesh '${geometryKey}' not found`);
        return;
    }
    
    const { mesh } = group;
    
    // Cria matriz de transformação
    const matrix = new THREE.Matrix4();
    
    const pos = new THREE.Vector3(...position);
    const rot = new THREE.Euler(...rotation);
    const scl = new THREE.Vector3(...scale);
    
    matrix.compose(pos, new THREE.Quaternion().setFromEuler(rot), scl);
    
    // Define matriz da instância
    mesh.setMatrixAt(instanceId, matrix);
    mesh.instanceMatrix.needsUpdate = true;
    
    // Incrementa contador
    group.count = Math.max(group.count, instanceId + 1);
    mesh.count = group.count;
    
    console.log(`📦 Instance ${instanceId} added to '${geometryKey}'`);
}

/**
 * Atualiza instância
 */
export function updateInstance(data) {
    const { geometryKey, instanceId, position, rotation, scale } = data;
    
    const group = instancedMeshes.get(geometryKey);
    if (!group) return;
    
    const { mesh } = group;
    
    // Atualiza matriz
    const matrix = new THREE.Matrix4();
    const pos = new THREE.Vector3(...position);
    const rot = new THREE.Euler(...rotation);
    const scl = new THREE.Vector3(...scale);
    
    matrix.compose(pos, new THREE.Quaternion().setFromEuler(rot), scl);
    
    mesh.setMatrixAt(instanceId, matrix);
    mesh.instanceMatrix.needsUpdate = true;
}

/**
 * Remove instância (marca como invisível)
 */
export function removeInstance(geometryKey, instanceId) {
    const group = instancedMeshes.get(geometryKey);
    if (!group) return;
    
    const { mesh } = group;
    
    // Move para fora da cena (esconde)
    const matrix = new THREE.Matrix4();
    matrix.makeScale(0, 0, 0); // Scale 0 = invisível
    
    mesh.setMatrixAt(instanceId, matrix);
    mesh.instanceMatrix.needsUpdate = true;
}

/**
 * Define cor de instância
 */
export function setInstanceColor(geometryKey, instanceId, color) {
    const group = instancedMeshes.get(geometryKey);
    if (!group) return;
    
    const { mesh } = group;
    
    // InstancedMesh suporta cores por instância
    if (!mesh.instanceColor) {
        mesh.instanceColor = new THREE.InstancedBufferAttribute(
            new Float32Array(mesh.count * 3),
            3
        );
    }
    
    const colorObj = new THREE.Color(color);
    mesh.instanceColor.setXYZ(instanceId, colorObj.r, colorObj.g, colorObj.b);
    mesh.instanceColor.needsUpdate = true;
}

/**
 * Estatísticas
 */
export function getInstancingStats() {
    const stats = {};
    
    instancedMeshes.forEach((group, key) => {
        stats[key] = {
            count: group.count,
            maxInstances: group.maxInstances,
            usage: (group.count / group.maxInstances * 100).toFixed(2) + '%'
        };
    });
    
    return stats;
}

/**
 * Remove InstancedMesh
 */
export function removeInstancedMesh(geometryKey) {
    const group = instancedMeshes.get(geometryKey);
    if (!group) return;
    
    const scene = getScene();
    scene.remove(group.mesh);
    
    group.mesh.geometry.dispose();
    group.mesh.material.dispose();
    
    instancedMeshes.delete(geometryKey);
}
