// scene.js - Scene management (migrado de SceneManager.ts)
import * as THREE from 'three';

let scene;
let fog;
let gridHelper;
let axesHelper;
let gridVisible = true;
let axesVisible = true;

export function initializeScene() {
    // Cria cena
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87ceeb);
    
    // Fog para profundidade
    fog = new THREE.Fog(0x87ceeb, 50, 500);
    scene.fog = fog;
    
    // Grid helper
    gridHelper = new THREE.GridHelper(100, 100, 0x888888, 0x444444);
    scene.add(gridHelper);
    
    // Axes helper
    axesHelper = new THREE.AxesHelper(10);
    scene.add(axesHelper);
    
    console.log('✅ Scene initialized (JS)');
}

export function setBackgroundColor(color) {
    scene.background = new THREE.Color(color);
    fog.color.set(color);
}

export function setFogDistance(near, far) {
    fog.near = near;
    fog.far = far;
}

export function toggleGrid() {
    gridVisible = !gridVisible;
    gridHelper.visible = gridVisible;
}

export function toggleAxes() {
    axesVisible = !axesVisible;
    axesHelper.visible = axesVisible;
}

export function addObject(objectJson) {
    // TODO: Deserializar JSON e adicionar à cena
    console.log('Add object:', objectJson);
}

export function removeObject(objectId) {
    const object = scene.getObjectByProperty('uuid', objectId);
    if (object) {
        scene.remove(object);
    }
}

export function clearScene() {
    while(scene.children.length > 0) {
        scene.remove(scene.children[0]);
    }
    
    // Re-adiciona helpers
    scene.add(gridHelper);
    scene.add(axesHelper);
}

export function getScene() {
    return scene;
}
