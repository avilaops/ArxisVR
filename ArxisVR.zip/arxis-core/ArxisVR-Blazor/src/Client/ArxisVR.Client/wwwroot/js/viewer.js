// viewer.js - Main viewer orchestrator (integrates scene, camera, input)
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { initializeScene, getScene } from './scene.js';
import { initializeCamera, getCamera, setControls } from './camera.js';

let renderer, controls;
let canvas;
let isInitialized = false;

/**
 * Inicializa o viewer Three.js completo
 * @param {string} canvasId - ID do elemento canvas
 */
export async function initViewer(canvasId) {
    console.log('🎨 Inicializando ArxisVR Viewer...');
    
    canvas = document.getElementById(canvasId);
    if (!canvas) {
        console.error('❌ Canvas não encontrado:', canvasId);
        return;
    }
    
    // Initialize modules
    initializeScene();
    initializeCamera();
    
    // Renderer
    renderer = new THREE.WebGLRenderer({ 
        canvas: canvas,
        antialias: true,
        alpha: true
    });
    renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    // Controls
    const camera = getCamera();
    controls = new OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 1;
    controls.maxDistance = 500;
    setControls(controls);
    
    // Resize handler
    window.addEventListener('resize', onWindowResize);
    
    // Start animation loop
    animate();
    
    isInitialized = true;
    console.log('✅ ArxisVR Viewer inicializado!');
}

/**
 * Loop de animação
 */
function animate() {
    requestAnimationFrame(animate);
    
    if (controls) {
        controls.update();
    }
    
    if (renderer && isInitialized) {
        const scene = getScene();
        const camera = getCamera();
        renderer.render(scene, camera);
    }
}

/**
 * Handler de resize
 */
function onWindowResize() {
    if (!canvas || !renderer || !isInitialized) return;
    
    const camera = getCamera();
    camera.aspect = canvas.clientWidth / canvas.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(canvas.clientWidth, canvas.clientHeight);
}

/**
 * Carrega arquivo IFC
 * @param {string} fileUrl - URL do arquivo IFC
 */
export async function loadIFC(fileUrl) {
    console.log('📦 Carregando IFC:', fileUrl);
    
    // TODO: Integrar IFC.js aqui
    // Por enquanto, criar um cubo de exemplo
    const scene = getScene();
    const geometry = new THREE.BoxGeometry(2, 2, 2);
    const material = new THREE.MeshStandardMaterial({ color: 0x00ff88 });
    const cube = new THREE.Mesh(geometry, material);
    cube.position.set(0, 1, 0);
    cube.castShadow = true;
    scene.add(cube);
    
    console.log('✅ IFC carregado (exemplo)');
}

/**
 * Define modo de navegação
 * @param {string} mode - fps, orbital, walkthrough, fly, topdown
 */
export function setNavigationMode(mode) {
    console.log('🎮 Mudando modo de navegação:', mode);
    
    switch(mode) {
        case 'fps':
            // TODO: Implementar controles FPS
            controls.enabled = false;
            break;
        case 'orbital':
            controls.enabled = true;
            break;
        case 'walkthrough':
            // TODO: Implementar walkthrough
            break;
        default:
            console.warn('Modo de navegação desconhecido:', mode);
    }
}

/**
 * Seleciona elemento pelo GUID
 * @param {string} guid - GUID do elemento IFC
 */
export function selectElement(guid) {
    console.log('🎯 Selecionando elemento:', guid);
    
    // TODO: Implementar seleção de elemento IFC
    // - Raycasting
    // - Highlight visual
    // - Notificar Blazor via callback
}

/**
 * Define plano de corte (clipping plane)
 * @param {string} axis - x, y, z
 * @param {number} position - Posição do plano
 */
export function setClippingPlane(axis, position) {
    console.log('✂️ Aplicando clipping plane:', axis, position);
    
    // TODO: Implementar clipping plane
    const scene = getScene();
    // Criar plane e aplicar ao renderer
}

/**
 * Limpa a cena
 */
export function clearScene() {
    const scene = getScene();
    while(scene.children.length > 0) { 
        scene.remove(scene.children[0]); 
    }
    
    // Re-adiciona grid e axes
    const gridHelper = new THREE.GridHelper(100, 100, 0x444444, 0x222222);
    scene.add(gridHelper);
    const axesHelper = new THREE.AxesHelper(5);
    scene.add(axesHelper);
}

/**
 * Dispose resources
 */
export function dispose() {
    if (renderer) {
        renderer.dispose();
    }
    window.removeEventListener('resize', onWindowResize);
}

// Export getters
export function getRenderer() {
    return renderer;
}
