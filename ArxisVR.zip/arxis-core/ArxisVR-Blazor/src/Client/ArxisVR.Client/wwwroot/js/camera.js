// camera.js - Camera management (migrado de CameraSystem.ts)
import * as THREE from 'three';

let camera;
let controls;

export function initializeCamera() {
    camera = new THREE.PerspectiveCamera(
        75, // FOV
        window.innerWidth / window.innerHeight,
        0.1, // Near
        1000 // Far
    );
    
    camera.position.set(0, 5, 10);
    
    // Resize handler
    window.addEventListener('resize', onWindowResize);
    
    console.log('✅ Camera initialized (JS)');
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
}

export function setCameraPosition(x, y, z) {
    camera.position.set(x, y, z);
}

export function setCameraRotation(x, y, z) {
    camera.rotation.set(x, y, z);
}

export function setCameraView(view) {
    switch(view) {
        case 'top':
            camera.position.set(0, 100, 0);
            camera.lookAt(0, 0, 0);
            break;
        case 'front':
            camera.position.set(0, 5, 50);
            camera.lookAt(0, 5, 0);
            break;
        case 'right':
            camera.position.set(50, 5, 0);
            camera.lookAt(0, 5, 0);
            break;
        case 'left':
            camera.position.set(-50, 5, 0);
            camera.lookAt(0, 5, 0);
            break;
        case 'isometric':
            camera.position.set(30, 30, 30);
            camera.lookAt(0, 0, 0);
            break;
        default:
            camera.position.set(0, 5, 10);
    }
}

export function focusSelection() {
    // TODO: Implementar focus na seleção
    console.log('Focus selection - TODO');
}

export function frameAll() {
    // TODO: Implementar frame all objects
    console.log('Frame all - TODO');
}

export function setCameraFOV(fov) {
    camera.fov = fov;
    camera.updateProjectionMatrix();
}

export function getCameraPosition() {
    return [
        camera.position.x,
        camera.position.y,
        camera.position.z
    ];
}

export function getCamera() {
    return camera;
}

export function setControls(controlsInstance) {
    controls = controlsInstance;
}
