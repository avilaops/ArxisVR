// engine.js - ArxisVR Engine Core (Three.js + WebGPU + Arxis-Core)
import * as THREE from 'three';
import WebGPURenderer from 'three/addons/renderers/webgpu/WebGPURenderer.js';
import { getScene } from './scene.js';
import { getCamera } from './camera.js';

let renderer = null;
let currentMode = 'webgl2';
let arxisCore = null; // Rust WASM module
let stats = {
    fps: 0,
    drawCalls: 0,
    triangles: 0,
    memoryUsed: 0,
    frameTime: 0
};

let lastFrameTime = performance.now();
let frameCount = 0;
let fpsUpdateTime = 0;

/**
 * Detecta suporte WebGPU
 */
export function detectWebGPU() {
    if ('gpu' in navigator) {
        console.log('✅ WebGPU API detected');
        return true;
    }
    console.log('❌ WebGPU not available');
    return false;
}

/**
 * Inicializa engine
 */
export async function initializeEngine(canvasId, mode = 'webgl2') {
    console.log(`🎨 Initializing engine with ${mode.toUpperCase()}...`);
    
    const canvas = document.getElementById(canvasId);
    if (!canvas) {
        throw new Error(`Canvas ${canvasId} not found`);
    }
    
    currentMode = mode;
    
    if (mode === 'webgpu' && detectWebGPU()) {
        await initializeWebGPU(canvas);
    } else {
        initializeWebGL2(canvas);
    }
    
    // Start render loop
    animate();
    
    console.log('✅ Engine initialized');
}

/**
 * Inicializa WebGPU renderer
 */
async function initializeWebGPU(canvas) {
    try {
        console.log('🔷 Initializing WebGPU renderer...');
        
        renderer = new WebGPURenderer({
            canvas: canvas,
            antialias: true
        });
        
        await renderer.init();
        
        renderer.setSize(canvas.clientWidth, canvas.clientHeight);
        renderer.setPixelRatio(window.devicePixelRatio);
        
        // WebGPU specific settings
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1;
        
        console.log('✅ WebGPU renderer initialized');
    } catch (error) {
        console.error('❌ WebGPU init failed:', error);
        console.log('⚠️ Falling back to WebGL2');
        currentMode = 'webgl2';
        initializeWebGL2(canvas);
    }
}

/**
 * Inicializa WebGL2 renderer (fallback)
 */
function initializeWebGL2(canvas) {
    console.log('🔶 Initializing WebGL2 renderer...');
    
    renderer = new THREE.WebGLRenderer({
        canvas: canvas,
        antialias: true,
        alpha: true,
        powerPreference: 'high-performance'
    });
    
    renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1;
    
    console.log('✅ WebGL2 renderer initialized');
}

/**
 * Carrega Arxis-Core (Rust WASM)
 */
export async function loadArxisCore() {
    try {
        console.log('🦀 Loading Arxis-Core WASM...');
        
        // Importa o módulo WASM compilado do Rust
        // Assumindo que o Arxis-Core está compilado para WASM e disponível
        const arxisCoreModule = await import('../wasm/arxis_core.js');
        await arxisCoreModule.default();
        
        arxisCore = arxisCoreModule;
        
        console.log('✅ Arxis-Core loaded successfully');
        
        // Teste de função Rust
        if (arxisCore.test_connection) {
            const result = arxisCore.test_connection();
            console.log('🦀 Arxis-Core test:', result);
        }
    } catch (error) {
        console.warn('⚠️ Arxis-Core not available:', error.message);
        console.log('   Engine will continue without Rust physics');
    }
}

/**
 * Loop de renderização
 */
function animate() {
    requestAnimationFrame(animate);
    
    const now = performance.now();
    const deltaTime = now - lastFrameTime;
    lastFrameTime = now;
    
    // Update FPS
    frameCount++;
    if (now - fpsUpdateTime >= 1000) {
        stats.fps = frameCount;
        frameCount = 0;
        fpsUpdateTime = now;
    }
    
    stats.frameTime = deltaTime;
    
    // Render
    if (renderer) {
        const scene = getScene();
        const camera = getCamera();
        
        if (scene && camera) {
            renderer.render(scene, camera);
            
            // Update stats
            if (renderer.info) {
                stats.drawCalls = renderer.info.render.calls;
                stats.triangles = renderer.info.render.triangles;
                stats.memoryUsed = renderer.info.memory?.geometries || 0;
            }
        }
    }
}

/**
 * Muda modo de renderização
 */
export async function setRenderMode(mode) {
    console.log(`🔄 Switching to ${mode.toUpperCase()}...`);
    
    if (mode === currentMode) {
        console.log('   Already in this mode');
        return;
    }
    
    // Dispose current renderer
    if (renderer) {
        renderer.dispose();
    }
    
    currentMode = mode;
    const canvas = renderer.domElement;
    
    if (mode === 'webgpu') {
        await initializeWebGPU(canvas);
    } else {
        initializeWebGL2(canvas);
    }
}

/**
 * Computa física usando Arxis-Core (Rust)
 */
export function computePhysics(inputJson) {
    if (!arxisCore) {
        console.warn('⚠️ Arxis-Core not loaded, using fallback physics');
        return computePhysicsFallback(inputJson);
    }
    
    try {
        const input = JSON.parse(inputJson);
        
        // Chama função Rust WASM
        const result = arxisCore.compute_physics(
            new Float64Array(input.position),
            new Float64Array(input.velocity),
            input.mass
        );
        
        return JSON.stringify({
            newPosition: Array.from(result.position),
            newVelocity: Array.from(result.velocity),
            force: Array.from(result.force)
        });
    } catch (error) {
        console.error('❌ Rust physics failed:', error);
        return computePhysicsFallback(inputJson);
    }
}

/**
 * Física JavaScript (fallback)
 */
function computePhysicsFallback(inputJson) {
    const input = JSON.parse(inputJson);
    
    // Física básica em JS
    const dt = 0.016; // 60 FPS
    const gravity = [0, -9.81, 0];
    
    const force = gravity.map(g => g * input.mass);
    const acceleration = force.map(f => f / input.mass);
    
    const newVelocity = input.velocity.map((v, i) => v + acceleration[i] * dt);
    const newPosition = input.position.map((p, i) => p + newVelocity[i] * dt);
    
    return JSON.stringify({
        newPosition,
        newVelocity,
        force
    });
}

/**
 * Obtém estatísticas do engine
 */
export function getEngineStats() {
    return JSON.stringify(stats);
}

/**
 * Resize handler
 */
window.addEventListener('resize', () => {
    if (renderer) {
        const canvas = renderer.domElement;
        const camera = getCamera();
        
        if (camera) {
            camera.aspect = canvas.clientWidth / canvas.clientHeight;
            camera.updateProjectionMatrix();
        }
        
        renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    }
});

/**
 * Dispose
 */
export function dispose() {
    if (renderer) {
        renderer.dispose();
    }
}

/**
 * Getters
 */
export function getRenderer() {
    return renderer;
}

export function getCurrentMode() {
    return currentMode;
}

export function getArxisCore() {
    return arxisCore;
}
