// lod-system.js - LOD System automático
import { getCamera } from './camera.js';
import * as THREE from 'three';

let settings = {};
const entities = new Map();
let frameCount = 0;

export function initializeLOD(lodSettings) {
    settings = lodSettings;
    console.log('✅ LOD System initialized');
}

/**
 * Registra entity no LOD
 */
export function registerEntity(entityData) {
    const { entityId, position, levels } = entityData;
    
    entities.set(entityId, {
        position: new THREE.Vector3(...position),
        levels,
        currentLevel: 0,
        lastDistance: 0
    });
}

/**
 * Remove entity
 */
export function unregisterEntity(entityId) {
    entities.delete(entityId);
}

/**
 * Update LOD (todo frame ou a cada N frames)
 */
export function updateLOD() {
    frameCount++;
    
    // Update a cada N frames
    if (settings.autoUpdate && frameCount % settings.updateFrequency !== 0) {
        return JSON.stringify(getStats());
    }
    
    const camera = getCamera();
    if (!camera) return JSON.stringify(getStats());
    
    const cameraPosition = camera.position;
    let totalTrianglesSaved = 0;
    
    entities.forEach((entity, entityId) => {
        // Calcula distância para câmera
        const distance = cameraPosition.distanceTo(entity.position);
        
        // Determina LOD level baseado na distância
        const newLevel = calculateLODLevel(distance, entity.levels);
        
        // Hysteresis - evita flickering
        const distanceDelta = Math.abs(distance - entity.lastDistance);
        if (distanceDelta < settings.hysteresisMargin && newLevel === entity.currentLevel) {
            return; // Sem mudança
        }
        
        // Muda LOD se necessário
        if (newLevel !== entity.currentLevel) {
            changeLODLevel(entityId, newLevel, entity);
            
            // Calcula triângulos economizados
            const originalTriangles = entity.levels[0].triangleCount;
            const currentTriangles = entity.levels[newLevel].triangleCount;
            totalTrianglesSaved += (originalTriangles - currentTriangles);
        }
        
        entity.lastDistance = distance;
    });
    
    return JSON.stringify({
        totalEntities: entities.size,
        trianglesSaved: totalTrianglesSaved,
        timestamp: Date.now()
    });
}

/**
 * Calcula qual LOD level usar baseado na distância
 */
function calculateLODLevel(distance, levels) {
    // Percorre levels do mais distante para o mais próximo
    for (let i = levels.length - 1; i >= 0; i--) {
        if (distance >= levels[i].distance) {
            return i;
        }
    }
    
    return 0; // Highest detail
}

/**
 * Muda LOD level de entity
 */
function changeLODLevel(entityId, newLevel, entity) {
    // TODO: Trocar mesh no Three.js
    // Por enquanto, apenas atualiza estado
    
    entity.currentLevel = newLevel;
    
    console.log(`🔄 Entity ${entityId} LOD changed to level ${newLevel}`);
}

/**
 * Força LOD específico
 */
export function setLODLevel(entityId, level) {
    const entity = entities.get(entityId);
    if (!entity) return;
    
    if (level >= 0 && level < entity.levels.length) {
        changeLODLevel(entityId, level, entity);
    }
}

/**
 * Estatísticas
 */
function getStats() {
    const levelCounts = {};
    
    entities.forEach(entity => {
        const level = entity.currentLevel;
        levelCounts[level] = (levelCounts[level] || 0) + 1;
    });
    
    return {
        totalEntities: entities.size,
        entitiesByLevel: levelCounts
    };
}

export function getEntityCount() {
    return entities.size;
}
