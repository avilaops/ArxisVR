// ifc-loader.js - IFC loading (migrado de IFCLoader.ts)
import { IFCLoader } from 'web-ifc-three/IFCLoader';
import { getScene } from './scene.js';
import * as THREE from 'three';

let ifcLoader;
let loadedModels = new Map();
let currentModelID = 0;

export function initializeIFCLoader() {
    ifcLoader = new IFCLoader();
    
    // Configura WASM path
    ifcLoader.ifcManager.setWasmPath('https://cdn.jsdelivr.net/npm/web-ifc@0.0.52/');
    
    // Otimizações
    ifcLoader.ifcManager.applyWebIfcConfig({
        COORDINATE_TO_ORIGIN: true,
        USE_FAST_BOOLS: true,
    });
    
    console.log('✅ IFC Loader initialized (JS)');
}

/**
 * Carrega IFC de base64
 */
export async function loadIFCFromBase64(fileName, base64Data, dotNetRef) {
    try {
        console.log(`📦 Loading IFC: ${fileName}`);
        
        // Converte base64 para Blob
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        
        // Carrega modelo
        const model = await new Promise((resolve, reject) => {
            ifcLoader.load(
                url,
                (loadedModel) => resolve(loadedModel),
                (progress) => {
                    const percent = (progress.loaded / progress.total) * 100;
                    dotNetRef.invokeMethodAsync('UpdateProgress', percent);
                },
                (error) => reject(error)
            );
        });
        
        URL.revokeObjectURL(url);
        
        // Processa modelo
        const modelData = await processModel(model, fileName);
        
        return JSON.stringify(modelData);
    } catch (error) {
        console.error('❌ Error loading IFC:', error);
        throw error;
    }
}

/**
 * Carrega IFC de URL
 */
export async function loadIFCFromUrl(url, dotNetRef) {
    try {
        console.log(`📦 Loading IFC from: ${url}`);
        
        const model = await new Promise((resolve, reject) => {
            ifcLoader.load(
                url,
                (loadedModel) => resolve(loadedModel),
                (progress) => {
                    if (progress.total > 0) {
                        const percent = (progress.loaded / progress.total) * 100;
                        dotNetRef.invokeMethodAsync('UpdateProgress', percent);
                    }
                },
                (error) => reject(error)
            );
        });
        
        const modelData = await processModel(model, url);
        return JSON.stringify(modelData);
    } catch (error) {
        console.error('❌ Error:', error);
        throw error;
    }
}

/**
 * Processa modelo carregado
 */
async function processModel(model, fileName) {
    const modelID = currentModelID++;
    model.userData.modelID = modelID;
    
    // Adiciona à cena
    const scene = getScene();
    scene.add(model);
    
    // Armazena modelo
    loadedModels.set(modelID, model);
    
    // Conta elementos e tipos
    const elementsByType = {};
    let elementCount = 0;
    
    model.traverse((child) => {
        if (child.isMesh) {
            elementCount++;
            
            // Armazena IDs
            child.userData.modelID = modelID;
            if (child.expressID) {
                child.userData.expressID = child.expressID;
            }
            
            // Conta por tipo
            const ifcType = detectIFCType(child);
            elementsByType[ifcType] = (elementsByType[ifcType] || 0) + 1;
        }
    });
    
    // Calcula bounding box
    const box = new THREE.Box3().setFromObject(model);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    
    console.log(`✅ IFC processed: ${elementCount} elements`);
    
    return {
        modelId: modelID,
        fileName: fileName,
        elementCount: elementCount,
        bounds: {
            min: { x: box.min.x, y: box.min.y, z: box.min.z },
            max: { x: box.max.x, y: box.max.y, z: box.max.z },
            center: { x: center.x, y: center.y, z: center.z },
            size: { x: size.x, y: size.y, z: size.z }
        },
        elementsByType: elementsByType
    };
}

/**
 * Detecta tipo IFC de um mesh
 */
function detectIFCType(mesh) {
    // Tenta obter tipo do userData ou nome
    if (mesh.userData.ifcType) return mesh.userData.ifcType;
    if (mesh.name) {
        // Extrai tipo do nome (geralmente vem como "IfcWall:123")
        const match = mesh.name.match(/Ifc(\w+)/);
        if (match) return `Ifc${match[1]}`;
    }
    return 'IfcUnknown';
}

/**
 * Obtém propriedades de elemento
 */
export async function getElementProperties(modelId, expressId) {
    const model = loadedModels.get(modelId);
    if (!model) {
        console.error('Model not found:', modelId);
        return JSON.stringify({});
    }
    
    try {
        const props = await ifcLoader.ifcManager.getItemProperties(modelId, expressId);
        const psets = await ifcLoader.ifcManager.getPropertySets(modelId, expressId);
        
        return JSON.stringify({
            expressId: expressId,
            type: props.type || 'Unknown',
            name: props.Name?.value || '',
            properties: props,
            propertySets: psets
        });
    } catch (error) {
        console.error('Error getting properties:', error);
        return JSON.stringify({});
    }
}

/**
 * Obtém elementos por tipo
 */
export async function getElementsByType(modelId, ifcType) {
    try {
        const ids = await ifcLoader.ifcManager.getAllItemsOfType(modelId, ifcType);
        return JSON.stringify(ids || []);
    } catch (error) {
        console.error('Error getting elements:', error);
        return JSON.stringify([]);
    }
}

/**
 * Remove modelo
 */
export function unloadModel(modelId) {
    const model = loadedModels.get(modelId);
    if (model) {
        const scene = getScene();
        scene.remove(model);
        loadedModels.delete(modelId);
        console.log(`🗑️ Model ${modelId} unloaded`);
    }
}

/**
 * Obtém modelo carregado
 */
export function getModel(modelId) {
    return loadedModels.get(modelId);
}
