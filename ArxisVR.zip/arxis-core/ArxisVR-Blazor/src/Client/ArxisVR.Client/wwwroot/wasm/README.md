# 🦀 Arxis-Core → WASM

## Compilar Rust para WebAssembly

### Pré-requisitos

```bash
# Instalar wasm-pack
cargo install wasm-pack

# Adicionar target wasm
rustup target add wasm32-unknown-unknown
```

### Compilar

No diretório do Avx-Core (projeto Rust):

```bash
# Build para web
wasm-pack build --target web --out-dir ../ArxisVR-Blazor/src/Client/ArxisVR.Client/wwwroot/wasm

# Build otimizado (release)
wasm-pack build --target web --release --out-dir ../ArxisVR-Blazor/src/Client/ArxisVR.Client/wwwroot/wasm
```

### Estrutura esperada

Após compilação, esta pasta deve conter:

```
wwwroot/wasm/
├── arxis_core.js         # JavaScript bindings
├── arxis_core_bg.wasm    # WebAssembly binary
├── arxis_core.d.ts       # TypeScript definitions
└── package.json
```

### Funções exportadas (exemplo)

```rust
// No Rust (lib.rs ou physics/mod.rs)
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn test_connection() -> String {
    "Arxis-Core connected!".to_string()
}

#[wasm_bindgen]
pub struct PhysicsResult {
    pub position: Vec<f64>,
    pub velocity: Vec<f64>,
    pub force: Vec<f64>,
}

#[wasm_bindgen]
pub fn compute_physics(
    position: &[f64],
    velocity: &[f64],
    mass: f64
) -> PhysicsResult {
    // Sua lógica de física aqui
    // Pode usar os módulos: physics/, geometry/, tensor/
    
    PhysicsResult {
        position: position.to_vec(),
        velocity: velocity.to_vec(),
        force: vec![0.0, -9.81 * mass, 0.0],
    }
}
```

### Uso no Blazor

O `EngineService.cs` e `engine.js` já estão configurados para:
1. Carregar o WASM automaticamente
2. Detectar se está disponível
3. Fallback para JavaScript se não tiver

### Desenvolvimento

Para desenvolvimento, você pode:

1. **Modo híbrido:** Engine funciona sem WASM (JS puro)
2. **Com WASM:** Compile e teste funcionalidades Rust
3. **Hot reload:** wasm-pack suporta watch mode

```bash
# Watch mode (recompila automaticamente)
wasm-pack build --target web --dev --out-dir ../ArxisVR-Blazor/src/Client/ArxisVR.Client/wwwroot/wasm
```

---

## 🎯 Integração completa

O engine ArxisVR usa:
- **Three.js** - Renderização 3D
- **WebGPU** - GPU acceleration (fallback WebGL2)
- **Arxis-Core (Rust/WASM)** - Física avançada, geometria, tensores

Tudo orquestrado pelo `EngineService.cs` em C#!
