using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using ArxisVR.Client;
using ArxisVR.Client.Services;
using ArxisVR.Client.State;
using ArxisVR.Client.ECS;
using ArxisVR.Client.Systems;
using MudBlazor.Services;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });

// MudBlazor
builder.Services.AddMudServices();

// Application State
builder.Services.AddSingleton<AppState>();

// ECS (Entity Component System)
builder.Services.AddScoped<ECSManager>();

// Engine Services
builder.Services.AddScoped<EngineService>(); // 🔥 Engine principal
builder.Services.AddScoped<ViewerService>();
builder.Services.AddScoped<SceneService>();
builder.Services.AddScoped<CameraService>();
builder.Services.AddScoped<InputService>();
builder.Services.AddScoped<WorkerService>(); // 🔨 Web Workers (multithread)

// Loaders
builder.Services.AddScoped<IFCService>();

// Systems
builder.Services.AddScoped<LODSystem>();
builder.Services.AddScoped<InstancingSystem>();

// TODO: Adicionar mais services conforme migração avança
// builder.Services.AddScoped<SelectionService>();
// builder.Services.AddScoped<MeasurementService>();

await builder.Build().RunAsync();
