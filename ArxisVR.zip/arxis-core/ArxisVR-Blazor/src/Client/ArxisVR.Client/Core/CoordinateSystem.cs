namespace ArxisVR.Client.Core;

/// <summary>
/// CoordinateSystem - Sistema de coordenadas global
/// Precisão métrica 1:1 + Georreferenciamento
/// </summary>
public class CoordinateSystem
{
    // Origin do sistema de coordenadas global
    public GeographicCoordinate GlobalOrigin { get; set; } = new();
    
    // Unidade base (metros)
    public double UnitScale { get; set; } = 1.0; // 1.0 = metros
    
    // Norte verdadeiro (ângulo em radianos)
    public double TrueNorth { get; set; } = 0.0;
    
    // Sistema de projeção (UTM, etc)
    public ProjectionSystem Projection { get; set; } = ProjectionSystem.LocalCartesian;
    
    /// <summary>
    /// Converte coordenadas geográficas para coordenadas locais
    /// </summary>
    public LocalCoordinate GeographicToLocal(GeographicCoordinate geographic)
    {
        // Simplificação: diferença em metros (para distâncias pequenas)
        // Para produção, usar proj4 ou similar
        
        double deltaLat = (geographic.Latitude - GlobalOrigin.Latitude) * 111320.0; // ~111.32 km por grau
        double deltaLon = (geographic.Longitude - GlobalOrigin.Longitude) * 111320.0 * 
                          Math.Cos(GlobalOrigin.Latitude * Math.PI / 180.0);
        double deltaAlt = geographic.Altitude - GlobalOrigin.Altitude;
        
        return new LocalCoordinate(deltaLon, deltaAlt, -deltaLat); // Three.js usa Z negativo para norte
    }
    
    /// <summary>
    /// Converte coordenadas locais para geográficas
    /// </summary>
    public GeographicCoordinate LocalToGeographic(LocalCoordinate local)
    {
        double lat = GlobalOrigin.Latitude + (local.Z / -111320.0);
        double lon = GlobalOrigin.Longitude + 
                     (local.X / (111320.0 * Math.Cos(GlobalOrigin.Latitude * Math.PI / 180.0)));
        double alt = GlobalOrigin.Altitude + local.Y;
        
        return new GeographicCoordinate(lat, lon, alt);
    }
    
    /// <summary>
    /// Aplica escala métrica a coordenadas
    /// </summary>
    public LocalCoordinate ApplyScale(LocalCoordinate coord)
    {
        return new LocalCoordinate(
            coord.X * UnitScale,
            coord.Y * UnitScale,
            coord.Z * UnitScale
        );
    }
    
    /// <summary>
    /// Remove escala métrica
    /// </summary>
    public LocalCoordinate RemoveScale(LocalCoordinate coord)
    {
        return new LocalCoordinate(
            coord.X / UnitScale,
            coord.Y / UnitScale,
            coord.Z / UnitScale
        );
    }
    
    /// <summary>
    /// Aplica rotação do norte verdadeiro
    /// </summary>
    public LocalCoordinate ApplyTrueNorth(LocalCoordinate coord)
    {
        double cos = Math.Cos(TrueNorth);
        double sin = Math.Sin(TrueNorth);
        
        return new LocalCoordinate(
            coord.X * cos - coord.Z * sin,
            coord.Y,
            coord.X * sin + coord.Z * cos
        );
    }
    
    /// <summary>
    /// Distância 3D entre dois pontos locais
    /// </summary>
    public double Distance(LocalCoordinate a, LocalCoordinate b)
    {
        double dx = b.X - a.X;
        double dy = b.Y - a.Y;
        double dz = b.Z - a.Z;
        
        return Math.Sqrt(dx * dx + dy * dy + dz * dz);
    }
    
    /// <summary>
    /// Distância geográfica (Haversine)
    /// </summary>
    public double GeographicDistance(GeographicCoordinate a, GeographicCoordinate b)
    {
        const double R = 6371000; // Raio da Terra em metros
        
        double lat1 = a.Latitude * Math.PI / 180.0;
        double lat2 = b.Latitude * Math.PI / 180.0;
        double dLat = (b.Latitude - a.Latitude) * Math.PI / 180.0;
        double dLon = (b.Longitude - a.Longitude) * Math.PI / 180.0;
        
        double x = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                   Math.Cos(lat1) * Math.Cos(lat2) *
                   Math.Sin(dLon / 2) * Math.Sin(dLon / 2);
        
        double c = 2 * Math.Atan2(Math.Sqrt(x), Math.Sqrt(1 - x));
        
        return R * c;
    }
}

/// <summary>
/// Coordenada geográfica (lat/lon/alt)
/// </summary>
public class GeographicCoordinate
{
    public double Latitude { get; set; }    // Graus (Norte positivo)
    public double Longitude { get; set; }   // Graus (Leste positivo)
    public double Altitude { get; set; }    // Metros acima do nível do mar
    
    public GeographicCoordinate() { }
    
    public GeographicCoordinate(double latitude, double longitude, double altitude = 0)
    {
        Latitude = latitude;
        Longitude = longitude;
        Altitude = altitude;
    }
    
    public override string ToString()
    {
        return $"Lat: {Latitude:F6}°, Lon: {Longitude:F6}°, Alt: {Altitude:F2}m";
    }
}

/// <summary>
/// Coordenada local cartesiana (X/Y/Z em metros)
/// </summary>
public class LocalCoordinate
{
    public double X { get; set; }  // Leste
    public double Y { get; set; }  // Altitude
    public double Z { get; set; }  // Norte (negativo no Three.js)
    
    public LocalCoordinate() { }
    
    public LocalCoordinate(double x, double y, double z)
    {
        X = x;
        Y = y;
        Z = z;
    }
    
    public override string ToString()
    {
        return $"X: {X:F2}m, Y: {Y:F2}m, Z: {Z:F2}m";
    }
}

/// <summary>
/// Sistema de projeção cartográfica
/// </summary>
public enum ProjectionSystem
{
    LocalCartesian,     // Coordenadas locais simples
    WGS84,              // Sistema geodésico mundial
    UTM,                // Universal Transverse Mercator
    WebMercator,        // Usado em mapas web
    Custom              // Projeção customizada
}

/// <summary>
/// Configuração de precisão
/// </summary>
public class PrecisionSettings
{
    // Escala IFC (geralmente 1:1 para metros)
    public double IfcScale { get; set; } = 1.0;
    
    // Tolerância para comparações de coordenadas
    public double Tolerance { get; set; } = 0.001; // 1mm
    
    // Usar double precision (64-bit) no Three.js
    public bool UseDoublePrecision { get; set; } = true;
    
    // Número máximo de casas decimais
    public int DecimalPlaces { get; set; } = 6;
}
