namespace ArxisVR.Client.Core;

/// <summary>
/// SceneGraph - Hierarquia espacial de elementos
/// Estrutura: Site → Building → Storey → Space → Element
/// </summary>
public class SceneGraph
{
    public SceneNode Root { get; private set; }
    
    // Cache para busca rápida
    private readonly Dictionary<string, SceneNode> _nodesByGuid = new();
    
    public SceneGraph()
    {
        Root = new SceneNode("Root", SceneNodeType.Root);
        _nodesByGuid["root"] = Root;
    }
    
    /// <summary>
    /// Adiciona nó à hierarquia
    /// </summary>
    public SceneNode AddNode(string guid, string name, SceneNodeType type, SceneNode? parent = null)
    {
        parent ??= Root;
        
        var node = new SceneNode(name, type)
        {
            Guid = guid,
            Parent = parent
        };
        
        parent.Children.Add(node);
        _nodesByGuid[guid] = node;
        
        return node;
    }
    
    /// <summary>
    /// Busca nó por GUID
    /// </summary>
    public SceneNode? FindNode(string guid)
    {
        return _nodesByGuid.GetValueOrDefault(guid);
    }
    
    /// <summary>
    /// Obtém todos nós de um tipo
    /// </summary>
    public List<SceneNode> GetNodesByType(SceneNodeType type)
    {
        return _nodesByGuid.Values
            .Where(n => n.Type == type)
            .ToList();
    }
    
    /// <summary>
    /// Caminho completo do nó (Site/Building/Storey/Space)
    /// </summary>
    public string GetFullPath(SceneNode node)
    {
        var path = new List<string>();
        var current = node;
        
        while (current != null && current != Root)
        {
            path.Insert(0, current.Name);
            current = current.Parent;
        }
        
        return string.Join("/", path);
    }
    
    /// <summary>
    /// Traverse tree com callback
    /// </summary>
    public void Traverse(Action<SceneNode> callback, SceneNode? start = null)
    {
        start ??= Root;
        
        callback(start);
        
        foreach (var child in start.Children)
        {
            Traverse(callback, child);
        }
    }
    
    /// <summary>
    /// Estatísticas
    /// </summary>
    public SceneGraphStats GetStats()
    {
        var stats = new SceneGraphStats();
        
        Traverse(node =>
        {
            stats.TotalNodes++;
            stats.NodesByType[node.Type] = stats.NodesByType.GetValueOrDefault(node.Type, 0) + 1;
            stats.MaxDepth = Math.Max(stats.MaxDepth, GetDepth(node));
        });
        
        return stats;
    }
    
    private int GetDepth(SceneNode node)
    {
        int depth = 0;
        var current = node;
        while (current != null && current != Root)
        {
            depth++;
            current = current.Parent;
        }
        return depth;
    }
}

/// <summary>
/// Nó do Scene Graph
/// </summary>
public class SceneNode
{
    public string Guid { get; set; } = string.Empty;
    public string Name { get; set; }
    public SceneNodeType Type { get; set; }
    
    public SceneNode? Parent { get; set; }
    public List<SceneNode> Children { get; } = new();
    
    // Transform local
    public Transform LocalTransform { get; set; } = new();
    
    // Metadata
    public Dictionary<string, object> Metadata { get; set; } = new();
    
    // Reference para entity ECS (se aplicável)
    public int? EntityId { get; set; }
    
    public SceneNode(string name, SceneNodeType type)
    {
        Name = name;
        Type = type;
    }
    
    /// <summary>
    /// Transform global (acumula transforms dos parents)
    /// </summary>
    public Transform GetGlobalTransform()
    {
        var transform = LocalTransform;
        var current = Parent;
        
        while (current != null)
        {
            transform = Transform.Combine(current.LocalTransform, transform);
            current = current.Parent;
        }
        
        return transform;
    }
    
    public override string ToString()
    {
        return $"{Type}: {Name} ({Children.Count} children)";
    }
}

/// <summary>
/// Tipos de nós na hierarquia IFC
/// </summary>
public enum SceneNodeType
{
    Root,
    Site,           // IfcSite
    Building,       // IfcBuilding
    Storey,         // IfcBuildingStorey
    Space,          // IfcSpace
    Element,        // IfcElement (wall, door, window, etc)
    Group           // Custom group
}

/// <summary>
/// Transform espacial
/// </summary>
public class Transform
{
    public Vector3D Position { get; set; } = new();
    public Quaternion Rotation { get; set; } = Quaternion.Identity;
    public Vector3D Scale { get; set; } = new(1, 1, 1);
    
    public static Transform Identity => new();
    
    /// <summary>
    /// Combina dois transforms (parent → child)
    /// </summary>
    public static Transform Combine(Transform parent, Transform child)
    {
        // TODO: Implementar multiplicação correta de transforms
        // Por enquanto, apenas soma posições
        return new Transform
        {
            Position = parent.Position + child.Position,
            Rotation = parent.Rotation * child.Rotation,
            Scale = new Vector3D(
                parent.Scale.X * child.Scale.X,
                parent.Scale.Y * child.Scale.Y,
                parent.Scale.Z * child.Scale.Z
            )
        };
    }
}

/// <summary>
/// Vector 3D
/// </summary>
public class Vector3D
{
    public double X { get; set; }
    public double Y { get; set; }
    public double Z { get; set; }
    
    public Vector3D() { }
    
    public Vector3D(double x, double y, double z)
    {
        X = x;
        Y = y;
        Z = z;
    }
    
    public static Vector3D operator +(Vector3D a, Vector3D b)
        => new(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
}

/// <summary>
/// Quaternion para rotações
/// </summary>
public class Quaternion
{
    public double X { get; set; }
    public double Y { get; set; }
    public double Z { get; set; }
    public double W { get; set; }
    
    public Quaternion() { }
    
    public Quaternion(double x, double y, double z, double w)
    {
        X = x;
        Y = y;
        Z = z;
        W = w;
    }
    
    public static Quaternion Identity => new(0, 0, 0, 1);
    
    public static Quaternion operator *(Quaternion a, Quaternion b)
    {
        // Multiplicação de quaternions
        return new Quaternion(
            a.W * b.X + a.X * b.W + a.Y * b.Z - a.Z * b.Y,
            a.W * b.Y - a.X * b.Z + a.Y * b.W + a.Z * b.X,
            a.W * b.Z + a.X * b.Y - a.Y * b.X + a.Z * b.W,
            a.W * b.W - a.X * b.X - a.Y * b.Y - a.Z * b.Z
        );
    }
}

/// <summary>
/// Estatísticas do Scene Graph
/// </summary>
public class SceneGraphStats
{
    public int TotalNodes { get; set; }
    public int MaxDepth { get; set; }
    public Dictionary<SceneNodeType, int> NodesByType { get; set; } = new();
}
