using Microsoft.JSInterop;
using ArxisVR.Client.ECS;

namespace ArxisVR.Client.Systems;

/// <summary>
/// LODSystem - Level of Detail automático
/// Ajusta geometria baseado na distância da câmera
/// Performance crítica para modelos grandes
/// </summary>
public class LODSystem
{
    private readonly IJSRuntime _jsRuntime;
    private readonly ECSManager _ecsManager;
    private IJSObjectReference? _lodModule;
    
    // Configurações
    public LODSettings Settings { get; set; } = new();
    
    // Cache
    private readonly Dictionary<int, LODCache> _lodCache = new();
    
    // Stats
    private LODStats _stats = new();
    
    public LODSystem(IJSRuntime jsRuntime, ECSManager ecsManager)
    {
        _jsRuntime = jsRuntime;
        _ecsManager = ecsManager;
    }
    
    /// <summary>
    /// Inicializa LOD System
    /// </summary>
    public async Task InitializeAsync()
    {
        _lodModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/lod-system.js");
            
        await _lodModule.InvokeVoidAsync("initializeLOD", Settings);
        Console.WriteLine("✅ LOD System initialized");
    }
    
    /// <summary>
    /// Registra entity no LOD System
    /// </summary>
    public async Task RegisterEntityAsync(Entity entity)
    {
        var lodComponent = entity.GetComponent<LODComponent>();
        if (lodComponent is null)
        {
            Console.WriteLine($"⚠️ Entity {entity.Id} has no LODComponent");
            return;
        }
        
        var transform = entity.GetComponent<TransformComponent>();
        if (transform is null) return;
        
        // Registra no JavaScript
        if (_lodModule is not null)
        {
            await _lodModule.InvokeVoidAsync("registerEntity", new
            {
                entityId = entity.Id,
                position = new[] { transform.Position.X, transform.Position.Y, transform.Position.Z },
                levels = lodComponent.Levels.Select(l => new
                {
                    level = l.Level,
                    distance = l.Distance,
                    meshId = l.MeshId,
                    triangleCount = l.TriangleCount
                }).ToArray()
            });
        }
        
        // Cacheia
        _lodCache[entity.Id] = new LODCache
        {
            EntityId = entity.Id,
            CurrentLevel = 0,
            LastUpdateTime = DateTime.UtcNow
        };
    }
    
    /// <summary>
    /// Remove entity do LOD System
    /// </summary>
    public async Task UnregisterEntityAsync(int entityId)
    {
        if (_lodModule is not null)
        {
            await _lodModule.InvokeVoidAsync("unregisterEntity", entityId);
        }
        
        _lodCache.Remove(entityId);
    }
    
    /// <summary>
    /// Update - chamado todo frame
    /// Calcula distância e ajusta LOD
    /// </summary>
    public async Task UpdateAsync()
    {
        if (_lodModule is null) return;
        
        // JavaScript faz o cálculo pesado
        var statsJson = await _lodModule.InvokeAsync<string>("updateLOD");
        
        // Update stats
        // TODO: Parse statsJson
        _stats.LastUpdateTime = DateTime.UtcNow;
    }
    
    /// <summary>
    /// Força LOD específico para entity
    /// </summary>
    public async Task SetLODLevelAsync(int entityId, int level)
    {
        if (_lodModule is null) return;
        
        await _lodModule.InvokeVoidAsync("setLODLevel", entityId, level);
        
        if (_lodCache.TryGetValue(entityId, out var cache))
        {
            cache.CurrentLevel = level;
            cache.LastUpdateTime = DateTime.UtcNow;
        }
    }
    
    /// <summary>
    /// Cria LOD levels automaticamente
    /// </summary>
    public List<LODLevel> GenerateLODLevels(int triangleCount)
    {
        var levels = new List<LODLevel>();
        
        // Level 0 - High detail (original)
        levels.Add(new LODLevel
        {
            Level = 0,
            Distance = Settings.HighDetailDistance,
            TriangleCount = triangleCount
        });
        
        // Level 1 - Medium detail (50% reduction)
        levels.Add(new LODLevel
        {
            Level = 1,
            Distance = Settings.MediumDetailDistance,
            TriangleCount = triangleCount / 2
        });
        
        // Level 2 - Low detail (75% reduction)
        levels.Add(new LODLevel
        {
            Level = 2,
            Distance = Settings.LowDetailDistance,
            TriangleCount = triangleCount / 4
        });
        
        // Level 3 - Impostor/Billboard (90% reduction)
        if (Settings.UseImpostors)
        {
            levels.Add(new LODLevel
            {
                Level = 3,
                Distance = Settings.ImpostorDistance,
                TriangleCount = 2 // Billboard = 2 triangles
            });
        }
        
        return levels;
    }
    
    /// <summary>
    /// Estatísticas
    /// </summary>
    public LODStats GetStats()
    {
        _stats.TotalEntities = _lodCache.Count;
        _stats.EntitiesByLevel = _lodCache
            .GroupBy(c => c.Value.CurrentLevel)
            .ToDictionary(g => g.Key, g => g.Count());
        
        return _stats;
    }
    
    public async ValueTask DisposeAsync()
    {
        if (_lodModule is not null)
        {
            await _lodModule.DisposeAsync();
        }
    }
}

/// <summary>
/// Configurações LOD
/// </summary>
public class LODSettings
{
    // Distâncias (em metros)
    public double HighDetailDistance { get; set; } = 20.0;
    public double MediumDetailDistance { get; set; } = 50.0;
    public double LowDetailDistance { get; set; } = 100.0;
    public double ImpostorDistance { get; set; } = 200.0;
    
    // Features
    public bool UseImpostors { get; set; } = true;
    public bool AutoUpdate { get; set; } = true;
    public int UpdateFrequency { get; set; } = 5; // Frames entre updates
    
    // Hysteresis (evita flickering)
    public double HysteresisMargin { get; set; } = 5.0; // metros
}

/// <summary>
/// Cache LOD para entity
/// </summary>
public class LODCache
{
    public int EntityId { get; set; }
    public int CurrentLevel { get; set; }
    public DateTime LastUpdateTime { get; set; }
}

/// <summary>
/// Estatísticas LOD
/// </summary>
public class LODStats
{
    public int TotalEntities { get; set; }
    public Dictionary<int, int> EntitiesByLevel { get; set; } = new();
    public DateTime LastUpdateTime { get; set; }
    public int TotalTrianglesSaved { get; set; }
}
