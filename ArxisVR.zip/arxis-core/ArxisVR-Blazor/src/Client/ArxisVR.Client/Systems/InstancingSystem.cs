using Microsoft.JSInterop;
using ArxisVR.Client.ECS;

namespace ArxisVR.Client.Systems;

/// <summary>
/// InstancingSystem - GPU Instancing para elementos repetidos
/// 1 draw call para N objetos idênticos = performance massiva
/// Crítico para: janelas, portas, colunas, mobiliário
/// </summary>
public class InstancingSystem
{
    private readonly IJSRuntime _jsRuntime;
    private readonly ECSManager _ecsManager;
    private IJSObjectReference? _instancingModule;
    
    // Grupos de instâncias (por geometria)
    private readonly Dictionary<string, InstanceGroup> _instanceGroups = new();
    
    // Stats
    private InstancingStats _stats = new();
    
    public InstancingSystem(IJSRuntime jsRuntime, ECSManager ecsManager)
    {
        _jsRuntime = jsRuntime;
        _ecsManager = ecsManager;
    }
    
    /// <summary>
    /// Inicializa Instancing System
    /// </summary>
    public async Task InitializeAsync()
    {
        _instancingModule = await _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import", "./js/instancing-system.js");
            
        await _instancingModule.InvokeVoidAsync("initializeInstancing");
        Console.WriteLine("✅ Instancing System initialized");
    }
    
    /// <summary>
    /// Adiciona entity para instancing
    /// Agrupa automaticamente por geometria
    /// </summary>
    public async Task AddInstanceAsync(Entity entity, string geometryKey)
    {
        var transform = entity.GetComponent<TransformComponent>();
        var mesh = entity.GetComponent<MeshComponent>();
        
        if (transform is null || mesh is null) return;
        
        // Cria grupo se não existe
        if (!_instanceGroups.ContainsKey(geometryKey))
        {
            _instanceGroups[geometryKey] = new InstanceGroup
            {
                GeometryKey = geometryKey,
                Instances = new List<InstanceData>()
            };
            
            // Cria instanced mesh no JavaScript
            if (_instancingModule is not null)
            {
                await _instancingModule.InvokeVoidAsync("createInstancedMesh", 
                    geometryKey, 
                    mesh.GeometryType,
                    1000); // Max instances
            }
        }
        
        var group = _instanceGroups[geometryKey];
        
        // Adiciona instância
        var instanceData = new InstanceData
        {
            EntityId = entity.Id,
            Position = transform.Position,
            Rotation = transform.Rotation,
            Scale = transform.Scale
        };
        
        group.Instances.Add(instanceData);
        
        // Update no JavaScript
        if (_instancingModule is not null)
        {
            await _instancingModule.InvokeVoidAsync("addInstance", new
            {
                geometryKey,
                instanceId = group.Instances.Count - 1,
                position = new[] { transform.Position.X, transform.Position.Y, transform.Position.Z },
                rotation = new[] { transform.Rotation.X, transform.Rotation.Y, transform.Rotation.Z },
                scale = new[] { transform.Scale.X, transform.Scale.Y, transform.Scale.Z }
            });
        }
        
        Console.WriteLine($"📦 Instance added to group '{geometryKey}' ({group.Instances.Count} instances)");
    }
    
    /// <summary>
    /// Detecta automaticamente elementos instanciáveis
    /// Agrupa elementos IFC idênticos
    /// </summary>
    public async Task<Dictionary<string, List<Entity>>> DetectInstanciableElementsAsync()
    {
        var groups = new Dictionary<string, List<Entity>>();
        
        // Obtém todas entities com IFC e Mesh
        var entities = _ecsManager.GetEntitiesWithComponent<IFCComponent>()
            .Where(e => e.HasComponent<MeshComponent>())
            .ToList();
        
        // Agrupa por tipo IFC
        foreach (var entity in entities)
        {
            var ifcComp = entity.GetComponent<IFCComponent>();
            if (ifcComp is null) continue;
            
            // Chave: tipo + geometria
            var key = $"{ifcComp.IfcType}";
            
            if (!groups.ContainsKey(key))
            {
                groups[key] = new List<Entity>();
            }
            
            groups[key].Add(entity);
        }
        
        // Filtra grupos com múltiplas instâncias
        var instanciableGroups = groups
            .Where(g => g.Value.Count >= 3) // Mínimo 3 para valer a pena
            .ToDictionary(g => g.Key, g => g.Value);
        
        Console.WriteLine($"🔍 Found {instanciableGroups.Count} instanciable groups:");
        foreach (var (key, list) in instanciableGroups)
        {
            Console.WriteLine($"   - {key}: {list.Count} instances");
        }
        
        return instanciableGroups;
    }
    
    /// <summary>
    /// Converte entities para instancing
    /// Substitui N meshes individuais por 1 instanced mesh
    /// </summary>
    public async Task ConvertToInstancingAsync(string geometryKey, List<Entity> entities)
    {
        Console.WriteLine($"🔄 Converting {entities.Count} entities to instancing ({geometryKey})...");
        
        foreach (var entity in entities)
        {
            await AddInstanceAsync(entity, geometryKey);
        }
        
        Console.WriteLine($"✅ Converted to instancing - Draw calls reduced: {entities.Count} → 1");
    }
    
    /// <summary>
    /// Update posição de instância (move, rotate, scale)
    /// </summary>
    public async Task UpdateInstanceAsync(string geometryKey, int instanceId, 
        ECS.Vector3 position, ECS.Vector3 rotation, ECS.Vector3 scale)
    {
        if (_instancingModule is null) return;
        
        await _instancingModule.InvokeVoidAsync("updateInstance", new
        {
            geometryKey,
            instanceId,
            position = new[] { position.X, position.Y, position.Z },
            rotation = new[] { rotation.X, rotation.Y, rotation.Z },
            scale = new[] { scale.X, scale.Y, scale.Z }
        });
    }
    
    /// <summary>
    /// Remove instância
    /// </summary>
    public async Task RemoveInstanceAsync(string geometryKey, int instanceId)
    {
        if (_instancingModule is null) return;
        
        await _instancingModule.InvokeVoidAsync("removeInstance", geometryKey, instanceId);
        
        if (_instanceGroups.TryGetValue(geometryKey, out var group))
        {
            if (instanceId >= 0 && instanceId < group.Instances.Count)
            {
                group.Instances.RemoveAt(instanceId);
            }
        }
    }
    
    /// <summary>
    /// Estatísticas
    /// </summary>
    public InstancingStats GetStats()
    {
        _stats.TotalGroups = _instanceGroups.Count;
        _stats.TotalInstances = _instanceGroups.Sum(g => g.Value.Instances.Count);
        _stats.DrawCallsSaved = _stats.TotalInstances - _stats.TotalGroups;
        _stats.GroupStats = _instanceGroups.ToDictionary(
            g => g.Key,
            g => g.Value.Instances.Count
        );
        
        return _stats;
    }
    
    public async ValueTask DisposeAsync()
    {
        if (_instancingModule is not null)
        {
            await _instancingModule.DisposeAsync();
        }
    }
}

/// <summary>
/// Grupo de instâncias
/// </summary>
public class InstanceGroup
{
    public string GeometryKey { get; set; } = string.Empty;
    public List<InstanceData> Instances { get; set; } = new();
}

/// <summary>
/// Dados de uma instância
/// </summary>
public class InstanceData
{
    public int EntityId { get; set; }
    public ECS.Vector3 Position { get; set; } = new();
    public ECS.Vector3 Rotation { get; set; } = new();
    public ECS.Vector3 Scale { get; set; } = new();
}

/// <summary>
/// Estatísticas de instancing
/// </summary>
public class InstancingStats
{
    public int TotalGroups { get; set; }
    public int TotalInstances { get; set; }
    public int DrawCallsSaved { get; set; }
    public Dictionary<string, int> GroupStats { get; set; } = new();
}
