# 🏗️ ArxisVR - Plataforma BIM Enterprise

## Blazor WebAssembly | BIM 4D · 5D · 6D · Digital Twin

[![.NET](https://img.shields.io/badge/.NET-8.0-purple)](https://dot net.microsoft.com/)
[![Blazor](https://img.shields.io/badge/Blazor-WebAssembly-blue)](https://blazor.net/)
[![Three.js](https://img.shields.io/badge/Three.js-0.160-green)](https://threejs.org/)
[![License](https://img.shields.io/badge/license-MIT-orange)](LICENSE)

---

## 📋 Sobre o Projeto

O **ArxisVR** é uma plataforma BIM enterprise-grade construída com **Blazor WebAssembly** e **.NET 8**, projetada para ser a **referência mundial em BIM 4D, 5D e 6D**.

### 🎯 Objetivos

- ✅ **Visualização 3D de alta performance** (Three.js + WebGL2)
- ✅ **Gestão completa de projetos BIM**
- ✅ **Planejamento temporal (BIM 4D)** - Cronogramas, simulação
- ✅ **Gestão de custos (BIM 5D)** - Orçamento, quantitativos
- ✅ **Operação & Ciclo de Vida (BIM 6D)** - Manutenção, Digital Twin
- ✅ **Colaboração real-time** (SignalR)
- ✅ **Arquitetura escalável** para 8 EPICs + 23 sub-EPICs

---

## 🚀 Status do Projeto

Este projeto está em **MIGRAÇÃO ATIVA** de TypeScript/Vite para Blazor WebAssembly.

### ✅ Concluído
- [x] Estrutura de projetos (.NET Solution)
- [x] Arquitetura base documentada
- [x] AppState (State Management)
- [x] ViewerService (JSInterop bridge)
- [x] Layout base (MudBlazor)
- [x] viewer.js (Three.js integration)

### ⏳ Em Progresso
- [ ] Migração completa Engine Layer
- [ ] IFCLoader & Streaming
- [ ] Tools (Selection, Measurement, etc)
- [ ] UI Components completos

### 📅 Roadmap
- [ ] BIM 4D (Cronograma + Timeline)
- [ ] BIM 5D (Custos + Orçamento)
- [ ] BIM 6D (Ativos + Digital Twin)
- [ ] Colaboração Real-time
- [ ] IA aplicada ao BIM

---

## 🏛️ Arquitetura

```
┌────────────────────────────────────┐
│     Blazor WebAssembly (C#)        │
│  ┌──────────┐    ┌──────────┐     │
│  │  Pages   │    │  State   │     │
│  └────┬─────┘    └────┬─────┘     │
│       │               │            │
│  ┌────▼───────────────▼─────┐     │
│  │      Services            │     │
│  └────┬─────────────────────┘     │
│       │                            │
│  ┌────▼────────┐  ┌──────────┐    │
│  │  JSInterop  │  │ HttpClient│    │
│  │  (Three.js) │  │  (API)    │    │
│  └─────────────┘  └────┬──────┘    │
└────────────────────────┼───────────┘
                         │
              ┌──────────▼──────────┐
              │  ASP.NET Core API   │
              │  + SignalR          │
              └──────────┬──────────┘
                         │
              ┌──────────▼──────────┐
              │  PostgreSQL / EF    │
              └─────────────────────┘
```

**Ver documentação completa:** [ARCHITECTURE.md](ARCHITECTURE.md)

---

## 📁 Estrutura do Projeto

```
ArxisVR.sln
├── src/
│   ├── Client/              # Blazor WebAssembly
│   │   ├── Pages/           # Páginas (rotas)
│   │   ├── Components/      # Componentes Razor
│   │   ├── Services/        # Lógica de negócio
│   │   ├── State/           # State management
│   │   └── wwwroot/         # Assets estáticos
│   │
│   ├── Server/              # ASP.NET Core API
│   │   ├── Controllers/     # API endpoints
│   │   ├── Hubs/            # SignalR hubs
│   │   └── Services/        # Business services
│   │
│   ├── Shared/              # DTOs & Models
│   │   └── Models/          # Domain models
│   │
│   └── Core/                # Business Logic
│       └── Engines/         # Core engines (4D, 5D, 6D)
│
└── tests/                   # Unit & Integration tests
```

---

## 🛠️ Stack Tecnológica

### Frontend
- **Blazor WebAssembly** (.NET 8) - Framework principal
- **MudBlazor** - UI Components (Material Design)
- **Three.js** - Renderização 3D (via JSInterop)
- **IFC.js** - Parser IFC
- **SignalR Client** - Real-time

### Backend
- **ASP.NET Core 8** - Web API
- **SignalR** - Real-time collaboration
- **Entity Framework Core** - ORM
- **PostgreSQL** - Database primário

### DevOps
- **Docker** - Containerização
- **Azure** - Cloud hosting
- **GitHub Actions** - CI/CD

---

## 🚀 Como Rodar

### Pré-requisitos

- [.NET 8 SDK](https://dotnet.microsoft.com/download)
- [Node.js 18+](https://nodejs.org/) (opcional, para Three.js dev)
- [PostgreSQL](https://www.postgresql.org/) (ou SQL Server)

### Desenvolvimento

```bash
# Clone o repositório
git clone https://github.com/avilaops/arxisvr
cd arxisvr-clone/ArxisVR-Blazor

# Restaurar dependências
dotnet restore

# Rodar o Client (Blazor WASM)
dotnet run --project src/Client/ArxisVR.Client/ArxisVR.Client.csproj

# Ou com hot-reload
dotnet watch --project src/Client/ArxisVR.Client/ArxisVR.Client.csproj

# Rodar o Server (API)
dotnet run --project src/Server/ArxisVR.Server/ArxisVR.Server.csproj
```

### Build para Produção

```bash
# Build Release
dotnet publish -c Release

# Output em: src/Client/ArxisVR.Client/bin/Release/net8.0/publish/wwwroot
```

---

## 📚 Documentação

- 📖 [ARCHITECTURE.md](ARCHITECTURE.md) - Arquitetura completa
- 🔄 [MIGRATION_GUIDE.md](MIGRATION_GUIDE.md) - Guia de migração TS → C#
- 🧩 [COMPONENTS.md](docs/COMPONENTS.md) - Documentação de componentes
- 🔌 [API.md](docs/API.md) - Documentação da API

---

## 🎯 EPICs Implementados

### EPIC 0 - Fundamentação
- ✅ Estrutura de projetos
- ⏳ IFC Parser
- ⏳ Engine 3D

### EPIC 1 - BIM 3D
- ⏳ Visualizador 3D
- ⏳ IFC Inspector
- ⏳ Query Engine

### EPIC 2 - BIM 4D
- 📅 Timeline
- 📅 Cronograma
- 📅 Simulação 4D

### EPIC 3 - BIM 5D
- 💰 Gestão de custos
- 💰 Orçamento
- 💰 Relatórios

### EPIC 4 - BIM 6D
- 🏢 Gestão de ativos
- 🏢 Manutenção
- 🏢 Digital Twin

### EPIC 5 - Governança
- 🔐 RBAC
- 🔐 Auditoria
- 🔐 ISO 19650

### EPIC 6 - Colaboração
- 🌍 Real-time sync
- 🌍 Comentários
- 🌍 Issues

### EPIC 7 - IA
- 🤖 Detecção de conflitos
- 🤖 Previsões
- 🤖 Copiloto BIM

### EPIC 8 - Ecossistema
- 📦 API pública
- 📦 SDK
- 📦 White-label

---

## 🤝 Contribuindo

Este é um projeto enterprise-grade. Contribuições são bem-vindas!

1. Fork o projeto
2. Crie sua feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add: Amazing Feature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

**Padrões:**
- ✅ Seguir arquitetura documentada
- ✅ Testes unitários obrigatórios
- ✅ Documentação inline (XML comments)
- ✅ Code review obrigatório

---

## 📝 License

Este projeto está sob a licença MIT. Ver [LICENSE](LICENSE) para mais detalhes.

---

## 👨‍💻 Autor

**Time ArxisVR**
- GitHub: [@avilaops](https://github.com/avilaops)
- Site: [arxisvr.com](https://arxisvr.com)

---

## 🌟 Stargazers

[![Stargazers repo roster for @avilaops/arxisvr](https://reporoster.com/stars/avilaops/arxisvr)](https://github.com/avilaops/arxisvr/stargazers)

---

**ArxisVR** - A plataforma BIM mais avançada do planeta 🚀
