# 🏗️ ARXISVR - ARQUITETURA BLAZOR WEBASSEMBLY

## Plataforma BIM Enterprise | 4D · 5D · 6D · Digital Twin

---

## 📋 VISÃO GERAL

O ArxisVR está sendo **migrado de TypeScript/Vite para Blazor WebAssembly** para criar uma plataforma BIM enterprise-grade com arquitetura sólida e escalável.

### 🎯 Objetivos da Migração

- ✅ **Type-Safety Total** - C# fortemente tipado
- ✅ **Performance** - AOT compilation, WASM nativo
- ✅ **Arquitetura Enterprise** - Camadas bem definidas
- ✅ **Backend Integration** - ASP.NET Core API nativo
- ✅ **SignalR Native** - Real-time colaboração
- ✅ **Escalabilidade** - Preparado para 8 EPICs + 23 sub-EPICs

---

## 🏛️ ARQUITETURA DE CAMADAS

```
┌─────────────────────────────────────────────────┐
│                   FRONTEND                       │
│            Blazor WebAssembly (.NET 8)          │
│                                                  │
│  ┌──────────────┐  ┌──────────────┐            │
│  │   UI Layer   │  │  State Mgmt  │            │
│  │  (Razor)     │  │  (AppState)  │            │
│  └──────┬───────┘  └──────┬───────┘            │
│         │                 │                     │
│  ┌──────▼─────────────────▼───────┐            │
│  │      Application Layer          │            │
│  │  (Services, Managers, Tools)    │            │
│  └──────┬──────────────────────────┘            │
│         │                                       │
│  ┌──────▼──────────┐  ┌────────────────┐       │
│  │  JSInterop      │  │   API Client   │       │
│  │  (Three.js)     │  │   (HttpClient) │       │
│  └─────────────────┘  └────────┬───────┘       │
└────────────────────────────────┼────────────────┘
                                 │
                        ┌────────▼────────┐
                        │   ASP.NET Core  │
                        │   Web API       │
                        │   (.NET 8)      │
                        └────────┬────────┘
                                 │
                        ┌────────▼────────┐
                        │   Data Layer    │
                        │   EF Core +     │
                        │   PostgreSQL    │
                        └─────────────────┘
```

---

## 📁 ESTRUTURA DE DIRETÓRIOS

### Blazor Client (Frontend)

```
src/Client/ArxisVR.Client/
│
├── Pages/                          # Páginas Razor
│   ├── Index.razor                 # Home
│   ├── Viewer/
│   │   ├── Viewer3D.razor          # Viewer 3D principal
│   │   └── ViewerControls.razor    # Controles do viewer
│   ├── BIM4D/
│   │   ├── Timeline.razor          # Timeline 4D
│   │   ├── Schedule.razor          # Cronograma
│   │   └── Simulation.razor        # Simulação 4D
│   ├── BIM5D/
│   │   ├── CostManagement.razor    # Gestão de custos
│   │   ├── Budgeting.razor         # Orçamento
│   │   └── Reports.razor           # Relatórios
│   └── BIM6D/
│       ├── Assets.razor            # Gestão de ativos
│       ├── Maintenance.razor       # Manutenção
│       └── DigitalTwin.razor       # Digital Twin
│
├── Components/                     # Componentes reutilizáveis
│   ├── Layout/
│   │   ├── MainLayout.razor        # Layout principal
│   │   ├── TopBar.razor            # Barra superior
│   │   ├── SidePanel.razor         # Painel lateral
│   │   └── BottomDock.razor        # Dock inferior
│   ├── UI/
│   │   ├── Button.razor            # Botão customizado
│   │   ├── Panel.razor             # Painel
│   │   ├── Modal.razor             # Modal
│   │   ├── DataGrid.razor          # Grid de dados
│   │   └── TreeView.razor          # Árvore hierárquica
│   └── BIM/
│       ├── IFCInspector.razor      # Inspector IFC
│       ├── PropertyGrid.razor      # Grid de propriedades
│       ├── LayerManager.razor      # Gerenciador de layers
│       └── ElementSelector.razor   # Seletor de elementos
│
├── Services/                       # Services (lógica de negócio)
│   ├── ViewerService.cs            # JSInterop Three.js
│   ├── IFCService.cs               # Serviço IFC
│   ├── BIM4DService.cs             # Serviço BIM 4D
│   ├── BIM5DService.cs             # Serviço BIM 5D
│   ├── BIM6DService.cs             # Serviço BIM 6D
│   ├── ProjectService.cs           # Gerenciamento de projetos
│   └── CollaborationService.cs     # Colaboração real-time
│
├── State/                          # State Management
│   ├── AppState.cs                 # Estado global da aplicação
│   ├── ViewerState.cs              # Estado do viewer
│   ├── ProjectState.cs             # Estado do projeto
│   ├── UserState.cs                # Estado do usuário
│   └── SelectionState.cs           # Estado de seleção
│
├── Models/                         # View Models (frontend)
│   ├── ViewerModels.cs
│   ├── ToolModels.cs
│   └── UIModels.cs
│
├── wwwroot/                        # Recursos estáticos
│   ├── js/
│   │   ├── viewer.js               # Three.js integration
│   │   ├── ifc-loader.js           # IFC.js integration
│   │   └── interop.js              # Helpers JSInterop
│   ├── css/
│   │   └── app.css                 # Estilos customizados
│   └── index.html                  # HTML root
│
├── Program.cs                      # Entry point
└── _Imports.razor                  # Imports globais
```

### ASP.NET Core Server (Backend)

```
src/Server/ArxisVR.Server/
│
├── Controllers/                    # API Controllers
│   ├── IFCController.cs            # Endpoints IFC
│   ├── ProjectController.cs        # Gerenciamento de projetos
│   ├── ScheduleController.cs       # BIM 4D
│   ├── CostController.cs           # BIM 5D
│   └── AssetController.cs          # BIM 6D
│
├── Hubs/                           # SignalR Hubs
│   ├── CollaborationHub.cs         # Colaboração real-time
│   ├── ViewerHub.cs                # Sync de viewer
│   └── NotificationHub.cs          # Notificações
│
├── Services/                       # Business Services
│   ├── IFCParserService.cs         # Parser IFC
│   ├── BIMEngineService.cs         # Engine BIM
│   ├── ScheduleService.cs          # Serviço de cronograma
│   └── CostCalculationService.cs   # Cálculo de custos
│
├── Data/                           # Data Access
│   ├── ApplicationDbContext.cs     # EF Core Context
│   └── Repositories/
│       ├── ProjectRepository.cs
│       └── IFCRepository.cs
│
└── Program.cs                      # Entry point
```

### Shared (DTOs & Models)

```
src/Shared/ArxisVR.Shared/
│
├── Models/                         # Domain Models
│   ├── IFC/
│   │   ├── IFCElement.cs
│   │   ├── IFCProperty.cs
│   │   ├── IFCProject.cs
│   │   └── IFCRelationship.cs
│   ├── BIM4D/
│   │   ├── Task.cs
│   │   ├── Schedule.cs
│   │   ├── Timeline.cs
│   │   └── Milestone.cs
│   ├── BIM5D/
│   │   ├── CostItem.cs
│   │   ├── Budget.cs
│   │   ├── Quantity.cs
│   │   └── Resource.cs
│   └── BIM6D/
│       ├── Asset.cs
│       ├── MaintenancePlan.cs
│       ├── Operation.cs
│       └── Sensor.cs
│
├── DTOs/                           # Data Transfer Objects
│   ├── ProjectDTO.cs
│   ├── IFCElementDTO.cs
│   └── UserDTO.cs
│
└── Interfaces/                     # Contratos compartilhados
    ├── IIFCService.cs
    └── IProjectService.cs
```

### Core (Business Logic)

```
src/Core/ArxisVR.Core/
│
├── Engines/                        # Core Business Engines
│   ├── IFCEngine/
│   │   ├── IFCParser.cs
│   │   ├── IFCValidator.cs
│   │   └── IFCOptimizer.cs
│   ├── BIM4DEngine/
│   │   ├── TimelineEngine.cs
│   │   ├── ScheduleSimulator.cs
│   │   └── ConflictDetector.cs
│   ├── BIM5DEngine/
│   │   ├── CostCalculator.cs
│   │   ├── BudgetManager.cs
│   │   └── QuantityTakeoff.cs
│   └── BIM6DEngine/
│       ├── AssetManager.cs
│       ├── MaintenanceScheduler.cs
│       └── OperationsEngine.cs
│
├── Interfaces/                     # Business Interfaces
│   ├── IIFCEngine.cs
│   ├── IBIM4DEngine.cs
│   └── IBIM5DEngine.cs
│
└── Utilities/
    ├── GeometryUtils.cs
    └── MathUtils.cs
```

---

## 🔄 FLUXO DE DADOS

### 1. Carregamento de IFC

```
User → Viewer3D.razor
    → ViewerService.cs (C#)
        → viewer.js (JSInterop)
            → Three.js + IFC.js
                → Renderização 3D

Paralelamente:
User → Upload IFC
    → IFCController.cs
        → IFCParserService.cs
            → ArxisVR.Core.IFCEngine
                → Salva no DB (PostgreSQL)
                    → Retorna metadados
                        → AppState.cs atualizado
```

### 2. Seleção de Elemento

```
User clica no canvas 3D
    → viewer.js (raycaster Three.js)
        → DotNet.invokeMethodAsync("OnElementSelected", guid)
            → ViewerService.cs
                → AppState.SelectedElementGuid = guid
                    → StateHasChanged()
                        → IFCInspector.razor atualiza
                            → Busca propriedades via API
                                → IFCController.GetProperties(guid)
```

### 3. Colaboração Real-time

```
User A faz mudança
    → CollaborationHub.SendChange(change)
        → SignalR Server broadcast
            → User B recebe via CollaborationService.cs
                → AppState atualizado
                    → UI re-renderiza automaticamente
```

---

## 🧩 COMPONENTES PRINCIPAIS

### 1. ViewerService (JSInterop Bridge)

**Responsabilidade:** Comunicação C# ↔ JavaScript (Three.js)

```csharp
public class ViewerService
{
    public async Task InitializeAsync(string canvasId)
    public async Task LoadIFCAsync(string fileUrl)
    public async Task SelectElementAsync(string guid)
    public async Task SetNavigationModeAsync(string mode)
    public async Task SetClippingPlaneAsync(string axis, double position)
}
```

### 2. AppState (Single Source of Truth)

**Responsabilidade:** Estado global da aplicação

```csharp
public class AppState
{
    // Viewer
    public ViewerMode CurrentViewerMode { get; set; }
    public string? SelectedElementGuid { get; set; }
    
    // Project
    public string? CurrentProjectId { get; set; }
    public bool IsModelLoaded { get; set; }
    
    // BIM 4D
    public DateTime? CurrentSimulationDate { get; set; }
    
    // Events
    public event Action? OnStateChanged;
}
```

### 3. viewer.js (Three.js Core)

**Responsabilidade:** Renderização 3D, IFC loading

```javascript
export function initViewer(canvasId)
export async function loadIFC(fileUrl)
export function selectElement(guid)
export function setNavigationMode(mode)
export function setClippingPlane(axis, position)
```

---

## 🔌 INTEGRAÇÕES

### Three.js (via JSInterop)
- ✅ Scene management
- ✅ Camera controls
- ✅ Rendering loop
- ✅ Raycasting (selection)

### IFC.js (via JSInterop)
- ✅ IFC parsing
- ✅ Geometry extraction
- ✅ Property extraction
- ✅ Spatial tree

### SignalR (nativo .NET)
- ✅ Real-time collaboration
- ✅ Cursor sharing
- ✅ Selection sync
- ✅ Comments

### MudBlazor (UI)
- ✅ Layout components
- ✅ Data grids
- ✅ Forms
- ✅ Dialogs

---

## 📊 TECNOLOGIAS

### Frontend
- **Blazor WebAssembly** - .NET 8
- **MudBlazor** - Material Design
- **Three.js** - Renderização 3D
- **IFC.js** - Parser IFC

### Backend
- **ASP.NET Core 8** - Web API
- **SignalR** - Real-time
- **Entity Framework Core** - ORM
- **PostgreSQL** - Database

### DevOps
- **Docker** - Containerização
- **Azure** - Cloud hosting
- **GitHub Actions** - CI/CD

---

## 🎯 PRINCÍPIOS DE ARQUITETURA

### 1. Separation of Concerns
- UI não conhece lógica de negócio
- Services não conhecem UI
- State management centralizado

### 2. Single Source of Truth
- AppState é a única fonte de verdade
- Toda mudança passa pelo state

### 3. Unidirectional Data Flow
- UI → Service → State → UI
- Eventos sempre sobem, dados sempre descem

### 4. Component Isolation
- Componentes reutilizáveis
- Props in, events out
- Sem side effects

### 5. Type Safety
- C# fortemente tipado
- DTOs compartilhados
- Contratos explícitos

---

## 🚀 PRÓXIMOS PASSOS

1. ✅ Estrutura base criada
2. ⏳ Migrar Engine (SceneManager, Camera)
3. ⏳ Migrar IFCLoader
4. ⏳ Migrar Tools (Selection, Measurement)
5. ⏳ Migrar UI Components
6. ⏳ Implementar BIM 4D
7. ⏳ Implementar BIM 5D
8. ⏳ Implementar BIM 6D

---

**Ver também:**
- [MIGRATION_GUIDE.md](MIGRATION_GUIDE.md) - Guia de migração detalhado
- [README.md](README.md) - Overview do projeto
