# 🔄 GUIA DE MIGRAÇÃO - TypeScript → Blazor C#

## Mapeamento completo: arxisvr-clone (TS) → ArxisVR-Blazor (C#)

---

## 📋 VISÃO GERAL

Este documento mapeia **TODO o código TypeScript** do projeto original para a **nova estrutura Blazor WebAssembly**.

---

## 🗺️ MAPEAMENTO DE ESTRUTURA

### Projeto Original (TypeScript/Vite)

```
arxisvr-clone/src/
├── engine/          → Renderização 3D (Three.js)
├── loaders/         → IFC Loading
├── tools/           → Ferramentas (Selection, Measurement)
├── systems/         → Sistemas (Lighting, LOD, Material)
├── app/             → Controllers & Managers
├── ui/              → UI Components
├── core/            → Types, EventBus, AppState
├── ai/              → IA & Pathfinding
├── network/         → Multiplayer & VoIP
├── scripting/       → Runtime scripting
├── vr/              → VR/XR systems
└── main.ts          → Entry point
```

### Projeto Novo (Blazor/C#)

```
ArxisVR-Blazor/src/
├── Client/
│   ├── Pages/       → Páginas Razor (rotas)
│   ├── Components/  → Componentes reutilizáveis
│   ├── Services/    → Lógica de negócio + JSInterop
│   ├── State/       → State management
│   └── wwwroot/js/  → JavaScript (Three.js, IFC.js)
├── Server/          → ASP.NET Core API
├── Shared/          → Models & DTOs
└── Core/            → Business logic C#
```

---

## 📦 MIGRAÇÃO MÓDULO POR MÓDULO

### 1️⃣ ENGINE LAYER

#### TS Original → C# Blazor

| TypeScript (src/engine/) | Blazor C# | Status |
|--------------------------|-----------|--------|
| `main.ts` | `Program.cs` + `App.razor` | ✅ Criado |
| `SceneManager.ts` | `Services/SceneService.cs` + `wwwroot/js/viewer.js` | ⏳ Migrar |
| `CameraSystem.ts` | `Services/CameraService.cs` + JSInterop | ⏳ Migrar |
| `InputSystem.ts` | `Services/InputService.cs` + JSInterop | ⏳ Migrar |
| `Renderer.ts` | `wwwroot/js/viewer.js` (Three.js) | ✅ Base criada |

**Estratégia:**
- ✅ Lógica de renderização permanece em **JavaScript** (Three.js)
- ✅ Gerenciamento de estado migra para **C#** (Services)
- ✅ Comunicação via **JSInterop**

**Exemplo:**

```typescript
// TS: src/engine/SceneManager.ts
export class SceneManager {
    scene: THREE.Scene;
    
    add(object: THREE.Object3D) {
        this.scene.add(object);
    }
}
```

```csharp
// C#: Services/SceneService.cs
public class SceneService
{
    private readonly ViewerService _viewer;
    
    public async Task AddObjectAsync(string objectData)
    {
        await _viewer.InvokeAsync("addObject", objectData);
    }
}
```

```javascript
// JS: wwwroot/js/viewer.js
export function addObject(objectData) {
    const object = parseObject(objectData);
    scene.add(object);
}
```

---

### 2️⃣ LOADERS LAYER

| TypeScript (src/loaders/) | Blazor C# | Status |
|---------------------------|-----------|--------|
| `IFCLoader.ts` | `Services/IFCService.cs` + `wwwroot/js/ifc-loader.js` | ⏳ Migrar |
| `IFCStreamingLoader.ts` | `Services/IFCStreamingService.cs` | ⏳ Migrar |

**Estratégia:**
- ✅ IFC.js permanece em **JavaScript**
- ✅ Gerenciamento de chunks/streaming em **C#**
- ✅ Metadados IFC salvos via **API ASP.NET Core**

**Fluxo de migração:**

```typescript
// TS Original
class IFCLoader {
    async loadIFC(file: File) {
        const model = await this.ifcAPI.OpenModel(file);
        return model;
    }
}
```

```csharp
// C# Blazor
public class IFCService
{
    private readonly IJSRuntime _js;
    private readonly HttpClient _http;
    
    public async Task<IFCModel> LoadIFCAsync(IBrowserFile file)
    {
        // 1. Upload para servidor
        var stream = file.OpenReadStream(maxAllowedSize: 500_000_000);
        var response = await _http.PostAsync("/api/ifc/upload", stream);
        var fileId = await response.Content.ReadAsStringAsync();
        
        // 2. Carregar via JavaScript
        await _js.InvokeVoidAsync("loadIFC", fileId);
        
        // 3. Buscar metadados do servidor
        var metadata = await _http.GetFromJsonAsync<IFCModel>($"/api/ifc/{fileId}");
        return metadata;
    }
}
```

```javascript
// JS: wwwroot/js/ifc-loader.js
import { IFCLoader } from 'web-ifc-three';

export async function loadIFC(fileId) {
    const loader = new IFCLoader();
    const url = `/api/ifc/download/${fileId}`;
    const model = await loader.loadAsync(url);
    scene.add(model);
}
```

---

### 3️⃣ TOOLS LAYER

| TypeScript (src/tools/) | Blazor C# | Status |
|-------------------------|-----------|--------|
| `Tool.ts` (interface) | `Interfaces/ITool.cs` | ⏳ Criar |
| `SelectionTool.ts` | `Services/SelectionService.cs` | ⏳ Migrar |
| `MeasurementTool.ts` | `Services/MeasurementService.cs` + `Components/BIM/MeasurementTool.razor` | ⏳ Migrar |
| `NavigationTool.ts` | JSInterop (controles Three.js) | ⏳ Migrar |
| `LayerTool.ts` | `Components/BIM/LayerManager.razor` | ⏳ Migrar |
| `SectionTool.ts` | `Services/SectionService.cs` + JSInterop | ⏳ Migrar |

**Estratégia:**
- ✅ UI das ferramentas → **Razor Components**
- ✅ Lógica → **C# Services**
- ✅ Interação 3D → **JavaScript + JSInterop**

**Exemplo - MeasurementTool:**

```typescript
// TS Original
class MeasurementTool {
    onPointerDown(event: PointerEvent) {
        const point = this.getIntersection(event);
        this.points.push(point);
    }
}
```

```razor
@* Razor Component: Components/BIM/MeasurementTool.razor *@
@inject MeasurementService MeasurementService

<MudPaper Class="pa-4">
    <MudText Typo="Typo.h6">Medir Distância</MudText>
    <MudButton OnClick="StartMeasurement">Iniciar</MudButton>
    
    @if (MeasurementService.IsActive)
    {
        <MudText>Distância: @MeasurementService.CurrentDistance m</MudText>
    }
</MudPaper>

@code {
    protected override void OnInitialized()
    {
        MeasurementService.OnDistanceChanged += StateHasChanged;
    }
    
    private async Task StartMeasurement()
    {
        await MeasurementService.StartAsync();
    }
}
```

```csharp
// C# Service: Services/MeasurementService.cs
public class MeasurementService
{
    private readonly ViewerService _viewer;
    public bool IsActive { get; private set; }
    public double CurrentDistance { get; private set; }
    public event Action? OnDistanceChanged;
    
    public async Task StartAsync()
    {
        IsActive = true;
        await _viewer.InvokeAsync("startMeasurement");
    }
    
    [JSInvokable]
    public void OnPointAdded(double x, double y, double z)
    {
        // Calcula distância em C#
        CurrentDistance = CalculateDistance(x, y, z);
        OnDistanceChanged?.Invoke();
    }
}
```

---

### 4️⃣ SYSTEMS LAYER

| TypeScript (src/systems/) | Blazor C# | Status |
|---------------------------|-----------|--------|
| `LightingSystem.ts` | `Services/LightingService.cs` + JSInterop | ⏳ Migrar |
| `LODSystem.ts` | `Services/LODService.cs` | ⏳ Migrar |
| `MaterialSystem.ts` | JSInterop (Three.js materials) | ⏳ Migrar |

---

### 5️⃣ APP LAYER (Controllers & Managers)

| TypeScript (src/app/) | Blazor C# | Status |
|-----------------------|-----------|--------|
| `AppController.ts` | `State/AppState.cs` | ✅ Parcial |
| `ToolManager.ts` | `Services/ToolManagerService.cs` | ⏳ Migrar |
| `ProjectManager.ts` | `Services/ProjectService.cs` | ⏳ Migrar |
| `SelectionManager.ts` | `State/SelectionState.cs` | ⏳ Migrar |
| `LayerManager.ts` | `Services/LayerService.cs` | ⏳ Migrar |

---

### 6️⃣ UI LAYER

| TypeScript (src/ui/) | Blazor C# | Status |
|----------------------|-----------|--------|
| `UI.ts` | `Components/Layout/MainLayout.razor` | ✅ Base criada |
| `TopBar.ts` | `Components/Layout/TopBar.razor` | ⏳ Migrar |
| `LeftPanel.ts` | `Components/Layout/LeftPanel.razor` | ⏳ Migrar |
| `RightInspector.ts` | `Components/BIM/PropertyInspector.razor` | ⏳ Migrar |

**Estratégia:**
- ✅ Tudo vira **Razor Components**
- ✅ Uso de **MudBlazor** para UI base
- ✅ State via **AppState.cs**

---

### 7️⃣ CORE LAYER

| TypeScript (src/core/) | Blazor C# | Status |
|------------------------|-----------|--------|
| `AppState.ts` | `State/AppState.cs` | ✅ Criado |
| `EventBus.ts` | C# Events / Delegates | ⏳ Migrar |
| `types.ts` | `Shared/Models/` | ⏳ Migrar |

**Estratégia:**
- ✅ TypeScript interfaces → **C# classes/records**
- ✅ EventBus → **C# events + delegates**
- ✅ Enums mantém nomenclatura

---

## 🔧 PADRÕES DE MIGRAÇÃO

### Pattern 1: TypeScript Class → C# Service + JSInterop

```typescript
// TS
export class MyFeature {
    private scene: THREE.Scene;
    
    doSomething() {
        // 3D logic
    }
}
```

```csharp
// C#
public class MyFeatureService
{
    private readonly ViewerService _viewer;
    
    public async Task DoSomethingAsync()
    {
        await _viewer.InvokeAsync("doSomething");
    }
}
```

### Pattern 2: UI Component → Razor Component

```typescript
// TS
class MyButton {
    render() {
        return `<button>Click</button>`;
    }
}
```

```razor
<!-- Razor -->
<MudButton OnClick="HandleClick">Click</MudButton>

@code {
    private void HandleClick() { }
}
```

### Pattern 3: State Management

```typescript
// TS
const state = {
    selectedElement: null
};
```

```csharp
// C#
public class AppState
{
    public string? SelectedElement { get; set; }
    public event Action? OnStateChanged;
    
    public void SetSelectedElement(string? element)
    {
        SelectedElement = element;
        OnStateChanged?.Invoke();
    }
}
```

---

## 📊 PRIORIDADES DE MIGRAÇÃO

### FASE 1 - Core (1-2 semanas)
1. ✅ AppState
2. ⏳ ViewerService (JSInterop base)
3. ⏳ IFCService (loading básico)
4. ⏳ SceneService

### FASE 2 - Tools (1 semana)
5. ⏳ SelectionTool
6. ⏳ MeasurementTool
7. ⏳ NavigationTool

### FASE 3 - UI (1 semana)
8. ⏳ Layout completo
9. ⏳ PropertyInspector
10. ⏳ LayerManager

### FASE 4 - BIM 4D (2 semanas)
11. ⏳ Timeline
12. ⏳ Schedule integration

### FASE 5 - BIM 5D (2 semanas)
13. ⏳ Cost management
14. ⏳ Budgeting

### FASE 6 - BIM 6D (2 semanas)
15. ⏳ Asset management
16. ⏳ Digital Twin

---

## ✅ CHECKLIST DE MIGRAÇÃO

Por módulo, seguir:

- [ ] 1. Mapear classes TS → C# classes
- [ ] 2. Identificar lógica 3D (fica em JS)
- [ ] 3. Identificar lógica de negócio (vai para C#)
- [ ] 4. Criar Services C#
- [ ] 5. Criar JSInterop methods
- [ ] 6. Criar Razor Components (se UI)
- [ ] 7. Atualizar AppState
- [ ] 8. Testes
- [ ] 9. Documentação

---

**Ver também:**
- [ARCHITECTURE.md](ARCHITECTURE.md) - Arquitetura completa
- [README.md](README.md) - Overview do projeto
