//! LISA Telemetry - Time Series Analysis (Simplified)

// TODO: Re-enable when avx_telemetry is available
// pub use avx_telemetry::anomaly::{Anomaly, AnomalyDetector};
// pub use avx_telemetry::observability::DataQualityAssessment;
// pub use avx_telemetry::TimeSeries;

// Re-export for easy access
// pub type LISATelemetry = avx_telemetry::TimeSeries;





